# StreamForge Pro

**Production-grade video streaming control panel**
RTMP · HLS · IPTV · Multi-server · Anti-leech · Real-time analytics

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     Internet / CDN                       │
└──────────────┬─────────────────────────┬────────────────┘
               │ RTMP (1935)             │ HLS (8080/443)
┌──────────────▼─────────────────────────▼────────────────┐
│            Nginx + RTMP Module (Origin)                  │
│   on_publish → API hook    HLS/DASH output               │
└──────────────┬─────────────────────────┬────────────────┘
               │                         │
┌──────────────▼──────────┐  ┌───────────▼────────────────┐
│   API (Fastify/Node.js)  │  │   Redis (cache + pub/sub)  │
│   :3000                  │  │   :6379                    │
└──────────────┬───────────┘  └────────────────────────────┘
               │
┌──────────────▼──────────────────────────────────────────┐
│            PostgreSQL 15 (primary data store)            │
│            :5432                                         │
└─────────────────────────────────────────────────────────┘
```

---

## Quick Start

### 1. Clone and configure

```bash
git clone https://github.com/yourorg/streamforge-pro
cd streamforge-pro
cp .env.example .env
```

Edit `.env` — change **all** passwords and secrets:

```bash
# Required — generate with: openssl rand -hex 32
JWT_SECRET=<64-char-random>
STREAM_TOKEN_SECRET=<32-char-random>
DB_PASSWORD=<strong-password>
REDIS_PASSWORD=<strong-password>
```

### 2. Start the stack

```bash
docker compose up -d
```

Services started:
| Service | Port | Description |
|---------|------|-------------|
| API | :3000 | REST API + Swagger docs |
| PostgreSQL | :5432 | Database (internal) |
| Redis | :6379 | Cache (internal) |
| Nginx-RTMP | :1935 | RTMP ingest |
| Nginx-RTMP | :8080 | HLS/DASH playback |
| Dashboard | :80 | Admin UI |

### 3. Access

- **API Docs**: http://localhost:3000/docs
- **Admin Panel**: http://localhost:80
- **Default login**: `admin@streamforge.local` / `Admin@StreamForge2025!`

> ⚠️ Change the admin password immediately after first login!

---

## API Reference

### Authentication

```bash
# Login
POST /api/v1/auth/login
{ "email": "admin@streamforge.local", "password": "..." }
→ { accessToken, refreshToken, user }

# All other endpoints: Authorization: Bearer <accessToken>

# Refresh
POST /api/v1/auth/refresh
{ "refreshToken": "..." }
```

### Streams

```bash
GET    /api/v1/streams              # List all streams
GET    /api/v1/streams/live         # Live streams only
POST   /api/v1/streams              # Create stream
GET    /api/v1/streams/:id          # Get stream details
PATCH  /api/v1/streams/:id          # Update stream
DELETE /api/v1/streams/:id          # Delete stream
POST   /api/v1/streams/:id/rotate-key  # Rotate RTMP key
POST   /api/v1/streams/:id/token       # Generate viewer token
GET    /api/v1/streams/:id/stats       # Viewer history
GET    /api/v1/streams/dashboard       # Dashboard stats
```

### Users

```bash
GET    /api/v1/users                # List broadcasters
POST   /api/v1/users                # Create broadcaster
GET    /api/v1/users/:id            # User details
PATCH  /api/v1/users/:id            # Update limits/permissions
POST   /api/v1/users/:id/suspend    # Suspend account
POST   /api/v1/users/:id/unsuspend  # Unsuspend account
DELETE /api/v1/users/:id            # Soft delete
POST   /api/v1/users/:id/login-as   # Impersonate (admin)
```

### Edge Servers

```bash
GET    /api/v1/servers              # All nodes
POST   /api/v1/servers              # Add node
PATCH  /api/v1/servers/:id          # Update node
DELETE /api/v1/servers/:id          # Remove node
POST   /api/v1/servers/:id/ping     # Manual health check
POST   /api/v1/servers/:id/drain    # Graceful drain
GET    /api/v1/servers/stats/summary # Cluster summary
```

### Security

```bash
GET    /api/v1/security/settings     # Security config
PATCH  /api/v1/security/settings     # Update config
GET    /api/v1/security/geo-rules    # Geo block/allow rules
POST   /api/v1/security/geo-rules    # Add rule
DELETE /api/v1/security/geo-rules/:id
GET    /api/v1/security/blocklist    # IP blocklist
POST   /api/v1/security/blocklist    # Block IP/CIDR
DELETE /api/v1/security/blocklist/:id
GET    /api/v1/security/alerts       # System alerts
GET    /api/v1/security/audit-log    # Audit trail
```

---

## Broadcasting

### OBS / Streaming Software Setup

```
Server:    rtmp://YOUR_SERVER_IP:1935/live
Stream Key: (from dashboard → Streams → your stream key)
```

### HLS Playback URL

```
https://hls.YOUR_DOMAIN/live/YOUR_STREAM_KEY/index.m3u8
```

### Anti-leech (Signed URLs)

```bash
# Generate token
POST /api/v1/streams/:id/token { "ttl": 3600 }
→ { token: "1234567890.abc123def456", expires: 1234567890 }

# Append to HLS URL
https://hls.YOUR_DOMAIN/live/KEY/index.m3u8?token=1234567890.abc123def456
```

---

## User Roles

| Role | Capabilities |
|------|-------------|
| `superadmin` | Full access, create admins, delete users |
| `admin` | Manage broadcasters, streams, servers, security |
| `broadcaster` | Own streams only, view own stats |

---

## Background Jobs

| Job | Interval | Purpose |
|-----|----------|---------|
| Node health check | 30s | Ping all edge nodes, update metrics |
| Stale stream watchdog | 2min | Auto-detect disconnected streams |
| Bandwidth aggregation | 1min | Track per-user monthly usage |
| IP blocklist cleanup | 1h | Remove expired blocks |
| Token cleanup | 6h | Purge expired refresh tokens |
| Stats pruning | Daily | Keep 30d viewer stats, 90d audit log |

---

## Edge Node API Contract

Each edge node must expose a `/health` endpoint:

```json
GET http://EDGE_IP:9090/health
Headers: X-Node-Secret: <node.api_secret>

Response:
{
  "cpu": 42.5,
  "ram": 61.2,
  "bw_mbps": 4800,
  "active_streams": 8,
  "active_viewers": 3241
}
```

---

## Production Checklist

- [ ] Change all default passwords in `.env`
- [ ] Set `JWT_SECRET` to 64+ random characters
- [ ] Configure SMTP for email alerts
- [ ] Put Nginx behind Cloudflare or your CDN
- [ ] Enable SSL (Let's Encrypt via certbot)
- [ ] Set `ALLOWED_ORIGINS` to your dashboard domain
- [ ] Configure firewall: only 80/443/1935 public
- [ ] Set up monitoring: `docker compose --profile monitoring up -d`
- [ ] Configure PostgreSQL backups
- [ ] Review geo-blocking rules
- [ ] Test RTMP publish + HLS playback end-to-end

---

## Scaling

### Add an edge node

1. Deploy a new server with Nginx-RTMP installed
2. Expose the health API on port 9090
3. Register via API: `POST /api/v1/servers`
4. The load balancer will route new streams automatically

### Horizontal API scaling

```yaml
api:
  deploy:
    replicas: 3
```

All state is in PostgreSQL + Redis — API is fully stateless.

---

## License

MIT — StreamForge Pro
