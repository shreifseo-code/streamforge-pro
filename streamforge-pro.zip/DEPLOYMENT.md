# StreamForge Pro — Deployment Guide (Ubuntu 22.04 LTS)

## لماذا Ubuntu 22.04 بدلاً من CentOS؟

| المعيار | Ubuntu 22.04 | CentOS 7 | CentOS Stream |
|---|---|---|---|
| **الدعم** | ✅ حتى 2027 | ❌ انتهى 2024 | ⚠️ متغير |
| **Docker** | ✅ أسهل التثبيت | ⚠️ قديم | ⚠️ معقد |
| **الحزم** | ✅ محدثة | ❌ قديمة جداً | ⚠️ غير مستقرة |
| **الأداء** | ✅ أحدث kernel | ⚠️ قديم | ⏳ متقلب |
| **المجتمع** | ✅ ضخم | ❌ متناقص | ⚠️ صغير |

**التوصية**: استخدم **Ubuntu 22.04 LTS** ✅

---

## المتطلبات

### Hardware الأدنى
```
CPU:        2 vCores (4 recommended)
RAM:        2 GB (4 GB recommended)
Storage:    20 GB SSD (100 GB+ for production)
Network:    1 Gbps (10 Gbps for multiple edge nodes)
```

### Software المطلوب
- Docker Engine 24+
- Docker Compose 2.20+
- Git
- Ubuntu 22.04 LTS

---

# خطوات التثبيت

## 1️⃣ تحضير السيرفر

### تحديث النظام
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git net-tools htop
```

### إنشاء مستخدم غير root (اختياري لكن آمن)
```bash
sudo useradd -m -s /bin/bash streamforge
sudo usermod -aG docker streamforge
sudo usermod -aG sudo streamforge
```

### تفعيل Firewall (UFW)
```bash
sudo ufw enable
sudo ufw allow 22/tcp      # SSH
sudo ufw allow 80/tcp      # HTTP
sudo ufw allow 443/tcp     # HTTPS
sudo ufw allow 1935/tcp    # RTMP
sudo ufw allow 8080/tcp    # HLS (optional if behind CDN)
sudo ufw status
```

---

## 2️⃣ تثبيت Docker

### التثبيت الرسمي
```bash
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# إضافة المستخدم الحالي
sudo usermod -aG docker $USER
newgrp docker
```

### التحقق
```bash
docker --version
docker run hello-world
```

---

## 3️⃣ تثبيت Docker Compose

```bash
sudo curl -L \
  "https://github.com/docker/compose/releases/download/v2.25.0/docker-compose-$(uname -s)-$(uname -m)" \
  -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose
docker-compose --version
```

---

## 4️⃣ نشر StreamForge Pro

### استنساخ المشروع
```bash
cd /opt
sudo git clone https://github.com/yourorg/streamforge-pro.git
sudo chown -R streamforge:streamforge /opt/streamforge-pro
cd /opt/streamforge-pro
```

### إعداد متغيرات البيئة
```bash
cp .env.example .env
nano .env
```

**املأ القيم التالية:**
```bash
# ✅ REQUIRED — أضفها قبل البدء

# كلمات المرور (استخدم: openssl rand -base64 32)
JWT_SECRET=CHANGE_ME_LONG_RANDOM_STRING_64_CHARS
STREAM_TOKEN_SECRET=CHANGE_ME_32_CHARS
DB_PASSWORD=CHANGE_ME_STRONG_PASSWORD
REDIS_PASSWORD=CHANGE_ME_STRONG_PASSWORD

# النطاق والـ URLs
API_BASE_URL=https://api.streamforge.yourdomain.com
HLS_BASE_URL=https://hls.streamforge.yourdomain.com
RTMP_HOST=rtmp.streamforge.yourdomain.com

# البريد الإلكتروني (Mailgun/SendGrid)
SMTP_HOST=smtp.mailgun.org
SMTP_PORT=587
SMTP_USER=postmaster@streamforge.yourdomain.com
SMTP_PASS=YOUR_MAILGUN_PASSWORD

# الملفات الشخصية
ADMIN_EMAIL=admin@yourdomain.com
ADMIN_PASSWORD=VeryStrongPassword123!@#
```

### إنشاء مجلدات البيانات المستمرة
```bash
mkdir -p data/{postgres,redis,nginx_logs,hls,dash}
sudo chown -R 1000:1000 data/
```

### التشغيل الأول
```bash
docker-compose up -d
```

### التحقق من الحالة
```bash
docker-compose ps
# جميع الحاويات يجب أن تظهر "Up"

# عرض السجلات
docker-compose logs -f api
```

---

## 5️⃣ إعداد Nginx Reverse Proxy (بدون Docker)

### التثبيت
```bash
sudo apt install -y nginx certbot python3-certbot-nginx
```

### الإعدادات (`/etc/nginx/sites-available/streamforge`)
```nginx
# API upstream
upstream api {
    server localhost:3000;
}

# HTTP → HTTPS redirect
server {
    listen 80;
    listen [::]:80;
    server_name api.streamforge.yourdomain.com;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 301 https://$host$request_uri;
    }
}

# HTTPS API
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.streamforge.yourdomain.com;

    ssl_certificate     /etc/letsencrypt/live/api.streamforge.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.streamforge.yourdomain.com/privkey.pem;

    ssl_protocols       TLSv1.2 TLSv1.3;
    ssl_ciphers         HIGH:!aNULL:!MD5;
    ssl_session_cache   shared:SSL:10m;
    ssl_session_timeout 10m;

    location / {
        proxy_pass http://api;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }
}

# RTMP
server {
    listen 1935;
    listen [::]:1935;
    server_name rtmp.streamforge.yourdomain.com;
    
    location / {
        # Docker container
        proxy_pass rtmp://localhost:1935;
    }
}
```

### التفعيل
```bash
sudo ln -s /etc/nginx/sites-available/streamforge /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### شهادة SSL (Let's Encrypt)
```bash
sudo certbot certonly --standalone \
  -d api.streamforge.yourdomain.com \
  -d hls.streamforge.yourdomain.com \
  -d rtmp.streamforge.yourdomain.com

# التجديد التلقائي
sudo systemctl enable certbot.timer
```

---

## 6️⃣ إعداد قاعدة البيانات

### التهيئة الأولى
```bash
docker-compose exec postgres psql -U streamforge -d streamforge \
  -f /docker-entrypoint-initdb.d/01-schema.sql
```

### التحقق
```bash
docker-compose exec postgres psql -U streamforge -d streamforge -c \
  "SELECT COUNT(*) as users FROM users;"
```

---

## 7️⃣ النسخ الاحتياطية

### إنشاء سكريبت النسخ
```bash
cat > /opt/streamforge-pro/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/opt/streamforge-pro/backups"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

mkdir -p $BACKUP_DIR

# PostgreSQL backup
docker-compose exec -T postgres pg_dump -U streamforge streamforge \
  | gzip > $BACKUP_DIR/db_$TIMESTAMP.sql.gz

# Redis backup
docker-compose exec -T redis redis-cli --rdb /tmp/dump.rdb
docker cp sf-redis:/tmp/dump.rdb $BACKUP_DIR/redis_$TIMESTAMP.rdb

# Keep last 30 days
find $BACKUP_DIR -name "*.gz" -mtime +30 -delete
find $BACKUP_DIR -name "*.rdb" -mtime +30 -delete

echo "Backup completed: $TIMESTAMP"
EOF

chmod +x /opt/streamforge-pro/backup.sh
```

### تنفيذ يومي (cron)
```bash
sudo crontab -e
# أضف السطر:
0 2 * * * /opt/streamforge-pro/backup.sh
```

---

## 8️⃣ المراقبة والصيانة

### Logs
```bash
# API logs
docker-compose logs -f api --tail 100

# Nginx
docker-compose logs -f nginx-rtmp

# كل الخدمات
docker-compose logs -f
```

### الموارد
```bash
# استخدام CPU/RAM
docker stats

# حجم الصور والحاويات
docker system df
```

### التنظيف
```bash
# حذف الصور القديمة
docker image prune -a

# حذف الحاويات المتوقفة
docker container prune

# المجموع
docker system prune -a
```

---

## 9️⃣ اختبار الإنتاج

### الوصول للـ APIs
```bash
# الصحة
curl https://api.streamforge.yourdomain.com/health

# Swagger docs
curl https://api.streamforge.yourdomain.com/docs

# تسجيل الدخول
curl -X POST https://api.streamforge.yourdomain.com/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@yourdomain.com","password":"..."}'
```

### اختبار البث
```bash
# FFmpeg publish
ffmpeg -re -i input.mp4 \
  -c:v libx264 -preset fast -b:v 2500k \
  -c:a aac -b:a 128k \
  -f flv rtmp://rtmp.streamforge.yourdomain.com/live/STREAM_KEY

# VLC playback
https://hls.streamforge.yourdomain.com/live/STREAM_KEY/index.m3u8
```

---

## 🔟 استكشاف الأخطاء

### الحاوية لا تبدأ
```bash
docker-compose logs postgres
# إذا كان الخطأ تصريح: احذف volume وأعد المحاولة
docker-compose down -v
docker-compose up -d
```

### الاتصال برفض RTMP
```bash
# تحقق من الـ firewall
sudo ufw allow 1935/tcp
# أعد تشغيل Nginx
docker-compose restart nginx-rtmp
```

### بطء قاعدة البيانات
```bash
# زيادة الموارد المخصصة
# في docker-compose.yml:
# postgres:
#   deploy:
#     resources:
#       limits:
#         memory: 2G

docker-compose up -d --no-deps --build postgres
```

---

## 📋 قائمة التحقق قبل الإنتاج

- [ ] تغيير جميع كلمات المرور في `.env`
- [ ] تفعيل SSL/TLS (Let's Encrypt)
- [ ] إعداد النسخ الاحتياطية التلقائية
- [ ] تكوين SMTP للـ alerts
- [ ] اختبار البث من OBS/FFmpeg
- [ ] اختبار التشغيل من VLC/Safari
- [ ] مراجعة سجلات الأمان (audit log)
- [ ] حد معدل (rate limiting) مفعّل
- [ ] قواعد Geo-blocking مفعّلة
- [ ] مراقبة الموارد في Prometheus
- [ ] نسخة احتياطية يومية تعمل
- [ ] اختبار failover (إيقاف حاوية واحدة)

---

## الدعم والمراجع

- **Docker Compose**: https://docs.docker.com/compose/
- **Ubuntu**: https://ubuntu.com/download/server
- **Let's Encrypt**: https://letsencrypt.org/
- **Nginx**: https://nginx.org/en/docs/

---

**آخر تحديث**: مايو 2026
**الإصدار المدعوم**: Ubuntu 22.04 LTS
