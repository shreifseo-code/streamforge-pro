# StreamForge Pro — API Reference

**Base URL**: `https://api.streamforge.yourdomain.com/api/v1`

**Authentication**: `Authorization: Bearer <accessToken>`

---

## Auth Endpoints

### `POST /auth/login`
**Public** — تسجيل الدخول
```bash
POST /auth/login
{
  "email": "user@example.com",
  "password": "password123"
}

Response 200:
{
  "accessToken": "eyJhbGc...",
  "refreshToken": "eyJhbGc...",
  "user": {
    "id": "uuid",
    "username": "john",
    "email": "john@example.com",
    "role": "broadcaster"
  }
}
```

### `POST /auth/refresh`
**Public** — تجديد التوكن المنتهي
```bash
POST /auth/refresh
{ "refreshToken": "..." }

Response 200: { "accessToken": "...", "refreshToken": "..." }
```

### `POST /auth/logout`
**Auth Required**
```bash
POST /auth/logout
{ "refreshToken": "..." }

Response 200: { "ok": true }
```

### `GET /auth/me`
**Auth Required** — بيانات المستخدم الحالي
```bash
GET /auth/me
Response 200: { id, username, email, role, max_viewers, ... }
```

### `POST /auth/change-password`
**Auth Required**
```bash
POST /auth/change-password
{
  "currentPassword": "old123",
  "newPassword": "new123NewPassword!"
}

Response 200: { "ok": true }
```

---

## Streams Endpoints

### `GET /streams`
**Auth Required** — قائمة الـ streams
```bash
GET /streams?page=1&limit=20&status=live

Response 200:
{
  "streams": [...],
  "total": 42,
  "page": 1,
  "limit": 20,
  "pages": 3
}
```

### `POST /streams`
**Auth Required** — إنشاء stream
```bash
POST /streams
{
  "name": "Sports Live HD",
  "description": "Live sports coverage",
  "stream_type": "rtmp_push",
  "max_viewers": 5000,
  "max_bitrate_kbps": 6000,
  "hls_qualities": ["1080p", "720p", "480p"],
  "token_auth_enabled": true,
  "token_expiry_sec": 3600
}

Response 201:
{
  "id": "uuid",
  "name": "Sports Live HD",
  "stream_key": "abc123xyz...",
  "rtmp_ingest": "rtmp://origin:1935/live/abc123xyz...",
  "hls_playback": "https://hls.../live/abc123xyz.../index.m3u8",
  "status": "idle",
  "created_at": "2026-05-20T16:00:00Z"
}
```

### `GET /streams/:id`
**Auth Required** — تفاصيل stream محدد
```bash
GET /streams/abc123-uuid
Response 200: { id, name, stream_key, status, current_viewers, ... }
```

### `PATCH /streams/:id`
**Auth Required** — تحديث stream
```bash
PATCH /streams/abc123-uuid
{
  "name": "Updated Name",
  "max_viewers": 3000,
  "allowed_referrers": ["example.com", "player.example.com"]
}

Response 200: { ... updated stream ... }
```

### `DELETE /streams/:id`
**Admin Only**
```bash
DELETE /streams/abc123-uuid
Response 204: (no content)
```

### `POST /streams/:id/rotate-key`
**Auth Required** — تدوير مفتاح البث (ضروري عند التسرب)
```bash
POST /streams/abc123-uuid/rotate-key
Response 200: { "streamKey": "newKey...", "updated": true }
```

### `POST /streams/:id/token`
**Auth Required** — توليد توكن للمشاهدة (anti-leech)
```bash
POST /streams/abc123-uuid/token
{ "ttl": 3600 }

Response 200:
{
  "token": "1234567890.abc123def456",
  "expires": 1234567890
}
```

### `GET /streams/:id/stats`
**Auth Required** — سجل المشاهدين (ساعات أو أيام)
```bash
GET /streams/abc123-uuid/stats?hours=24

Response 200:
{
  "history": [
    { "bucket": "2026-05-20T15:00:00Z", "viewers": 1240, "bitrate_kbps": 4200 },
    ...
  ]
}
```

### `GET /streams/live`
**Auth Required** — البث المباشر فقط
```bash
GET /streams/live
Response 200: { "streams": [...], "total": 5 }
```

### `GET /streams/dashboard`
**Admin Only** — إحصائيات لوحة التحكم
```bash
GET /streams/dashboard

Response 200:
{
  "live_streams": 14,
  "total_viewers": 8432,
  "total_gbps": 4.7,
  "nodes_online": 9,
  "nodes_total": 10,
  "active_broadcasters": 184,
  "nodes": [...],
  "alerts": [...]
}
```

---

## Users Endpoints (Admin)

### `GET /users`
**Admin Only** — قائمة broadcasters
```bash
GET /users?page=1&limit=20&role=broadcaster&status=active

Response 200:
{
  "users": [
    {
      "id": "uuid",
      "username": "john",
      "email": "john@example.com",
      "role": "broadcaster",
      "status": "active",
      "max_viewers": 500,
      "max_streams": 3,
      "live_streams": 1,
      "total_streams": 5,
      "last_login_at": "2026-05-20T..."
    },
    ...
  ],
  "total": 184,
  "pages": 10
}
```

### `POST /users`
**Admin Only** — إنشاء broadcaster
```bash
POST /users
{
  "username": "newuser",
  "email": "new@example.com",
  "password": "SecurePass123!@#",
  "display_name": "New User",
  "max_viewers": 1000,
  "max_streams": 5,
  "allow_youtube": false,
  "allow_facebook": true
}

Response 201: { "id", "username", "email", "role", "status", "created_at" }
```

### `GET /users/:id`
**Auth Required** (self or admin)
```bash
GET /users/abc123-uuid
Response 200: { ... full user data ... }
```

### `PATCH /users/:id`
**Admin Only** — تحديث حدود المستخدم
```bash
PATCH /users/abc123-uuid
{
  "max_viewers": 2000,
  "max_bitrate_kbps": 8000,
  "allow_twitch": true
}

Response 200: { ... updated user ... }
```

### `POST /users/:id/suspend`
**Admin Only** — تعليق الحساب
```bash
POST /users/abc123-uuid/suspend
{ "reason": "Payment failed" }

Response 200: { "ok": true }
```

### `POST /users/:id/unsuspend`
**Admin Only** — إعادة تفعيل
```bash
POST /users/abc123-uuid/unsuspend
Response 200: { "ok": true }
```

### `DELETE /users/:id`
**Superadmin Only** — حذف نهائي (soft delete)
```bash
DELETE /users/abc123-uuid
Response 204: (no content)
```

### `POST /users/:id/login-as`
**Admin Only** — محاكاة (impersonate) مستخدم
```bash
POST /users/abc123-uuid/login-as
Response 200: { "accessToken": "...", "user": { ... } }
```

### `GET /users/:id/streams`
**Auth Required** (self or admin)
```bash
GET /users/abc123-uuid/streams
Response 200: { "streams": [...], "total": 3 }
```

---

## Servers (Edge Nodes) Endpoints

### `GET /servers`
**Auth Required** — قائمة العُقد
```bash
GET /servers

Response 200:
{
  "nodes": [
    {
      "id": "uuid",
      "name": "SG-01 Origin",
      "region": "Singapore",
      "ip_address": "103.21.x.x",
      "status": "online",
      "cpu_pct": 42.5,
      "ram_pct": 61.2,
      "bw_out_mbps": 4800,
      "active_streams": 8,
      "active_viewers": 3241,
      "latency_ms": 12
    },
    ...
  ],
  "total": 10
}
```

### `POST /servers`
**Admin Only** — إضافة عقدة جديدة
```bash
POST /servers
{
  "name": "EU-DE-02",
  "region": "Frankfurt",
  "country_code": "DE",
  "flag_emoji": "🇩🇪",
  "ip_address": "49.12.x.x",
  "rtmp_port": 1935,
  "hls_port": 8080,
  "is_origin": false,
  "max_streams": 100
}

Response 201: { ... new node ... }
```

### `PATCH /servers/:id`
**Admin Only** — تحديث عقدة
```bash
PATCH /servers/abc123-uuid
{ "status": "maintenance", "max_streams": 80 }

Response 200: { ... updated node ... }
```

### `POST /servers/:id/ping`
**Admin Only** — فحص صحة يدوي
```bash
POST /servers/abc123-uuid/ping
Response 200: { "ok": true, "latency": 12, "metrics": { ... } }
```

### `POST /servers/:id/drain`
**Admin Only** — إيقاف تدريجي قبل الصيانة
```bash
POST /servers/abc123-uuid/drain
Response 200: { "ok": true, "status": "draining" }
```

### `GET /servers/stats/summary`
**Admin Only** — ملخص الحالة
```bash
GET /servers/stats/summary

Response 200:
{
  "total": 10,
  "online": 9,
  "offline": 1,
  "avg_cpu": 44.2,
  "avg_ram": 58.5,
  "total_active_streams": 42,
  "total_active_viewers": 8432,
  "total_bw_gbps": 4.7
}
```

---

## Security Endpoints (Admin)

### `GET /security/settings`
**Admin Only**
```bash
GET /security/settings

Response 200:
{
  "tokenAuth": true,
  "tokenExpiry": 3600,
  "rateLimit": 200,
  "autoRotateKey": true,
  "geoBlockingEnabled": true
}
```

### `PATCH /security/settings`
**Admin Only** — تحديث إعدادات الأمان
```bash
PATCH /security/settings
{
  "tokenAuth": true,
  "rateLimit": 300,
  "autoRotateKey": true
}

Response 200: { "ok": true }
```

### `GET /security/geo-rules`
**Admin Only**
```bash
GET /security/geo-rules

Response 200:
{
  "rules": [
    { "id": "uuid", "country_code": "RU", "action": "block", "stream_name": null },
    { "id": "uuid", "country_code": "AE", "action": "allow", "stream_name": null }
  ]
}
```

### `POST /security/geo-rules`
**Admin Only** — إضافة قاعدة حجب جغرافي
```bash
POST /security/geo-rules
{
  "country_code": "CN",
  "action": "block",
  "stream_id": null,
  "user_id": null
}

Response 201: { "id", "country_code", "action", ... }
```

### `GET /security/blocklist`
**Admin Only** — قائمة IP المحجوبة
```bash
GET /security/blocklist

Response 200:
{
  "blocked": [
    { "id": "uuid", "cidr": "1.2.3.4/32", "reason": "Brute force", "expires_at": null }
  ]
}
```

### `POST /security/blocklist`
**Admin Only** — حجب IP/CIDR
```bash
POST /security/blocklist
{
  "cidr": "192.168.1.0/24",
  "reason": "Suspicious activity",
  "expires_hours": 24
}

Response 201: { "id", "cidr", "reason", ... }
```

### `GET /security/alerts`
**Admin Only** — التنبيهات الحالية
```bash
GET /security/alerts?resolved=false&limit=50

Response 200:
{
  "alerts": [
    {
      "id": "uuid",
      "severity": "critical",
      "title": "Node SG-01 is offline",
      "body": "Last ping: 5 minutes ago",
      "created_at": "2026-05-20T..."
    }
  ]
}
```

### `PATCH /security/alerts/:id/resolve`
**Admin Only** — إغلاق تنبيه
```bash
PATCH /security/alerts/abc123-uuid/resolve
Response 200: { "ok": true }
```

### `GET /security/audit-log`
**Admin Only** — سجل الأنشطة
```bash
GET /security/audit-log?action=login&page=1&limit=50

Response 200:
{
  "log": [
    {
      "id": 12345,
      "user_id": "uuid",
      "username": "admin",
      "action": "stream_created",
      "entity": "stream",
      "ip": "203.0.113.x",
      "created_at": "2026-05-20T..."
    }
  ]
}
```

---

## WebHook Endpoints (Nginx ← API)

### `POST /streams/rtmp/publish`
**Nginx RTMP Hook** — تُستدعى عند البدء
```bash
POST /streams/rtmp/publish
X-RTMP-Secret: <RTMP_HOOK_SECRET>
{
  "name": "stream_key_here",
  "addr": "203.0.113.x"
}

Response 200: { "allow": true } — اسمح بالبث
Response 403: { "allow": false } — ارفض البث
```

### `POST /streams/rtmp/done`
**Nginx RTMP Hook** — تُستدعى عند الانقطاع
```bash
POST /streams/rtmp/done
X-RTMP-Secret: <RTMP_HOOK_SECRET>
{ "name": "stream_key_here" }

Response 200: { "ok": true }
```

---

## Status Codes

| Code | الوصف |
|------|--------|
| **200** | نجح ✅ |
| **201** | تم الإنشاء ✅ |
| **204** | تم الحذف بنجاح ✅ |
| **400** | طلب غير صحيح ❌ |
| **401** | غير مصرّح (توكن مفقود/منتهي) ❌ |
| **403** | ممنوع (لا توجد صلاحيات) ❌ |
| **404** | غير موجود ❌ |
| **409** | تضارب (مثلاً مستخدم موجود بالفعل) ❌ |
| **429** | الكثير من الطلبات (rate limit) ⏳ |
| **500** | خطأ في السيرفر 💥 |

---

## Error Response Format

```json
{
  "error": "التوصيف الإنساني للخطأ",
  "statusCode": 400,
  "details": [
    "username is required",
    "password must be at least 12 characters"
  ]
}
```

---

## Rate Limiting

- **الحد الافتراضي**: 200 طلب لكل 60 ثانية
- **رسالة التجاوز**:
```json
{
  "error": "Rate limit exceeded",
  "statusCode": 429,
  "retryAfter": 60
}
```

---

## Bearer Token Example

```bash
curl -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  https://api.streamforge.yourdomain.com/api/v1/users
```

---

**آخر تحديث**: مايو 2026 | جميع الـ endpoints يعملون
