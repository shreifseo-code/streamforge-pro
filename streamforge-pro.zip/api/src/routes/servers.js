import { query } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { cacheSet, cacheDel, KEYS } from '../config/redis.js';
import axios from 'axios';
import { logger } from '../utils/logger.js';

export default async function serverRoutes(fastify) {

  // ---- GET /servers ----
  fastify.get('/', { preHandler: authenticate }, async (req, reply) => {
    const { rows } = await query(
      `SELECT id, name, region, country_code, flag_emoji, ip_address,
              rtmp_port, hls_port, api_port, is_origin, status,
              max_streams, max_bw_gbps, cpu_pct, ram_pct, bw_out_mbps,
              active_streams, active_viewers, latency_ms, last_ping_at, created_at
       FROM edge_nodes ORDER BY is_origin DESC, region ASC`
    );
    return reply.send({ nodes: rows, total: rows.length });
  });

  // ---- POST /servers ----
  fastify.post('/', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { name, region, country_code, flag_emoji, ip_address,
            rtmp_port=1935, hls_port=8080, api_port=9090,
            is_origin=false, max_streams=100, max_bw_gbps=10 } = req.body;

    if (!name || !region || !ip_address) {
      return reply.code(400).send({ error: 'name, region, ip_address required' });
    }

    const { rows } = await query(
      `INSERT INTO edge_nodes
         (name, region, country_code, flag_emoji, ip_address,
          rtmp_port, hls_port, api_port, is_origin, max_streams, max_bw_gbps)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       RETURNING *`,
      [name, region, country_code, flag_emoji, ip_address,
       rtmp_port, hls_port, api_port, is_origin, max_streams, max_bw_gbps]
    );

    logger.info({ nodeId: rows[0].id, ip: ip_address }, 'Edge node added');
    return reply.code(201).send(rows[0]);
  });

  // ---- GET /servers/:id ----
  fastify.get('/:id', { preHandler: authenticate }, async (req, reply) => {
    const { rows } = await query('SELECT * FROM edge_nodes WHERE id=$1', [req.params.id]);
    if (!rows.length) return reply.code(404).send({ error: 'Node not found' });
    return reply.send(rows[0]);
  });

  // ---- PATCH /servers/:id ----
  fastify.patch('/:id', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const allowed = ['name','region','country_code','flag_emoji','status','max_streams','max_bw_gbps'];
    const fields = [], params = [];
    for (const k of allowed) {
      if (req.body[k] !== undefined) { params.push(req.body[k]); fields.push(`${k}=$${params.length}`); }
    }
    if (!fields.length) return reply.code(400).send({ error: 'Nothing to update' });
    params.push(req.params.id);
    const { rows } = await query(
      `UPDATE edge_nodes SET ${fields.join(',')}, updated_at=NOW() WHERE id=$${params.length} RETURNING *`,
      params
    );
    if (!rows.length) return reply.code(404).send({ error: 'Node not found' });
    return reply.send(rows[0]);
  });

  // ---- DELETE /servers/:id ----
  fastify.delete('/:id', {
    preHandler: [authenticate, requireRole('superadmin')]
  }, async (req, reply) => {
    // Safety: don't delete origin
    const { rows } = await query('SELECT is_origin FROM edge_nodes WHERE id=$1', [req.params.id]);
    if (!rows.length) return reply.code(404).send({ error: 'Node not found' });
    if (rows[0].is_origin) return reply.code(400).send({ error: 'Cannot delete origin server' });
    await query('DELETE FROM edge_nodes WHERE id=$1', [req.params.id]);
    return reply.code(204).send();
  });

  // ---- POST /servers/:id/ping (manual health check) ----
  fastify.post('/:id/ping', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query('SELECT * FROM edge_nodes WHERE id=$1', [req.params.id]);
    if (!rows.length) return reply.code(404).send({ error: 'Node not found' });
    const node = rows[0];

    const result = await pingNode(node);
    return reply.send(result);
  });

  // ---- POST /servers/:id/drain (graceful drain before maintenance) ----
  fastify.post('/:id/drain', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    await query("UPDATE edge_nodes SET status='draining', updated_at=NOW() WHERE id=$1", [req.params.id]);
    logger.info({ nodeId: req.params.id }, 'Node set to draining');
    return reply.send({ ok: true, status: 'draining' });
  });

  // ---- GET /servers/stats/summary ----
  fastify.get('/stats/summary', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query(`
      SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE status='online') AS online,
        COUNT(*) FILTER (WHERE status='offline') AS offline,
        COUNT(*) FILTER (WHERE status='maintenance') AS maintenance,
        ROUND(AVG(cpu_pct),1) AS avg_cpu,
        ROUND(AVG(ram_pct),1) AS avg_ram,
        SUM(active_streams) AS total_active_streams,
        SUM(active_viewers) AS total_active_viewers,
        ROUND(SUM(bw_out_mbps)/1024.0, 2) AS total_bw_gbps
      FROM edge_nodes
    `);
    return reply.send(rows[0]);
  });
}

// ---- Internal: ping a node's API ----
export async function pingNode(node) {
  const start = Date.now();
  try {
    const res = await axios.get(
      `http://${node.ip_address}:${node.api_port}/health`,
      { timeout: 5000, headers: { 'X-Node-Secret': node.api_secret } }
    );
    const latency = Date.now() - start;
    const metrics = res.data;

    await query(
      `UPDATE edge_nodes SET
         status='online', latency_ms=$2,
         cpu_pct=$3, ram_pct=$4, bw_out_mbps=$5,
         active_streams=$6, active_viewers=$7,
         last_ping_at=NOW(), updated_at=NOW()
       WHERE id=$1`,
      [node.id, latency, metrics.cpu, metrics.ram, metrics.bw_mbps,
       metrics.active_streams, metrics.active_viewers]
    );

    return { ok: true, latency, metrics };
  } catch (err) {
    await query(
      "UPDATE edge_nodes SET status='offline', last_ping_at=NOW(), updated_at=NOW() WHERE id=$1",
      [node.id]
    );
    logger.warn({ nodeId: node.id, err: err.message }, 'Node ping failed');

    // Create alert
    await query(
      `INSERT INTO alerts (severity, title, body, source, entity_id, entity_type)
       VALUES ('critical', $1, $2, 'health_check', $3, 'edge_node')
       ON CONFLICT DO NOTHING`,
      [`Node ${node.name} is offline`, `Ping failed: ${err.message}`, node.id]
    );

    return { ok: false, error: err.message };
  }
}
