import { authenticate, requireRole, requireOwnership } from '../middleware/auth.js';
import * as svc from '../services/streamService.js';
import { query } from '../config/db.js';
import { logger } from '../utils/logger.js';

export default async function streamRoutes(fastify) {

  // ---- GET /streams ----
  fastify.get('/', { preHandler: authenticate }, async (req, reply) => {
    const { status, page = 1, limit = 20 } = req.query;
    const result = await svc.listStreams({
      userId: req.user.id,
      role:   req.user.role,
      status, page: parseInt(page), limit: parseInt(limit)
    });
    return reply.send(result);
  });

  // ---- GET /streams/dashboard ----
  fastify.get('/dashboard', { preHandler: [authenticate, requireRole('superadmin','admin')] }, async (req, reply) => {
    const stats = await svc.getDashboardStats();
    return reply.send(stats);
  });

  // ---- GET /streams/live ----
  fastify.get('/live', { preHandler: authenticate }, async (req, reply) => {
    const { rows } = await query(`
      SELECT s.id, s.name, s.stream_key, s.stream_type, s.status,
             s.current_viewers, s.current_bitrate_kbps, s.peak_viewers,
             s.started_at,
             EXTRACT(EPOCH FROM (NOW()-s.started_at))::INT AS uptime_sec,
             u.username, u.email,
             n.name AS node_name, n.region, n.flag_emoji
      FROM streams s
      JOIN users u ON s.user_id = u.id
      LEFT JOIN edge_nodes n ON s.node_id = n.id
      WHERE s.status='live'
        ${req.user.role === 'broadcaster' ? 'AND s.user_id=$1' : ''}
      ORDER BY s.current_viewers DESC
    `, req.user.role === 'broadcaster' ? [req.user.id] : []);
    return reply.send({ streams: rows, total: rows.length });
  });

  // ---- POST /streams ----
  fastify.post('/', { preHandler: authenticate }, async (req, reply) => {
    // Check stream limit for broadcaster
    if (req.user.role === 'broadcaster' && req.user.max_streams > 0) {
      const { rows } = await query(
        "SELECT COUNT(*) FROM streams WHERE user_id=$1 AND status != 'disabled'",
        [req.user.id]
      );
      if (parseInt(rows[0].count) >= req.user.max_streams) {
        return reply.code(400).send({ error: `Stream limit reached (${req.user.max_streams})` });
      }
    }

    const stream = await svc.createStream(req.user.id, req.body);
    await query(
      "INSERT INTO audit_log (user_id,action,entity,entity_id,ip) VALUES ($1,'stream_created','stream',$2,$3)",
      [req.user.id, stream.id, req.ip]
    );
    return reply.code(201).send(stream);
  });

  // ---- GET /streams/:id ----
  fastify.get('/:id', { preHandler: authenticate }, async (req, reply) => {
    const stream = await svc.getStream(req.params.id, req.user.id, req.user.role);
    if (!stream) return reply.code(404).send({ error: 'Stream not found' });
    return reply.send(stream);
  });

  // ---- PATCH /streams/:id ----
  fastify.patch('/:id', { preHandler: authenticate }, async (req, reply) => {
    if (req.user.role === 'broadcaster') {
      const { rows } = await query('SELECT user_id FROM streams WHERE id=$1', [req.params.id]);
      if (!rows.length || rows[0].user_id !== req.user.id) {
        return reply.code(403).send({ error: 'Access denied' });
      }
    }
    const updated = await svc.updateStream(req.params.id, req.body);
    if (!updated) return reply.code(404).send({ error: 'Stream not found' });
    return reply.send(updated);
  });

  // ---- DELETE /streams/:id ----
  fastify.delete('/:id', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    await svc.deleteStream(req.params.id);
    await query(
      "INSERT INTO audit_log (user_id,action,entity,entity_id,ip) VALUES ($1,'stream_deleted','stream',$2,$3)",
      [req.user.id, req.params.id, req.ip]
    );
    return reply.code(204).send();
  });

  // ---- POST /streams/:id/rotate-key ----
  fastify.post('/:id/rotate-key', { preHandler: authenticate }, async (req, reply) => {
    if (req.user.role === 'broadcaster') {
      const { rows } = await query('SELECT user_id FROM streams WHERE id=$1', [req.params.id]);
      if (!rows.length || rows[0].user_id !== req.user.id) {
        return reply.code(403).send({ error: 'Access denied' });
      }
    }
    const stream = await svc.rotateStreamKey(req.params.id);
    return reply.send({ streamKey: stream.stream_key, updated: true });
  });

  // ---- POST /streams/:id/token (generate viewer token) ----
  fastify.post('/:id/token', { preHandler: authenticate }, async (req, reply) => {
    const { ttl } = req.body || {};
    const result = svc.generateViewToken(req.params.id, ttl || 3600);
    return reply.send(result);
  });

  // ---- GET /streams/:id/stats ----
  fastify.get('/:id/stats', { preHandler: authenticate }, async (req, reply) => {
    const { hours = 1 } = req.query;
    const history = await svc.getViewerHistory(req.params.id, parseInt(hours));
    return reply.send({ history });
  });

  // ---- POST /streams/rtmp/publish (called by Nginx-RTMP on_publish) ----
  fastify.post('/rtmp/publish', async (req, reply) => {
    const secret = req.headers['x-rtmp-secret'];
    if (secret !== process.env.RTMP_HOOK_SECRET) {
      return reply.code(403).send({ error: 'Forbidden' });
    }
    const { name: streamKey, addr: nodeIp } = req.body;
    const result = await svc.onStreamPublish(streamKey, nodeIp);
    if (!result.allow) return reply.code(403).send({ error: 'Unknown stream key' });
    return reply.send({ ok: true });
  });

  // ---- POST /streams/rtmp/done (called by Nginx-RTMP on_done) ----
  fastify.post('/rtmp/done', async (req, reply) => {
    const secret = req.headers['x-rtmp-secret'];
    if (secret !== process.env.RTMP_HOOK_SECRET) {
      return reply.code(403).send({ error: 'Forbidden' });
    }
    const { name: streamKey } = req.body;
    await svc.onStreamDone(streamKey);
    return reply.send({ ok: true });
  });
}
