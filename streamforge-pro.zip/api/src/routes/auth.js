import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import { query, transaction } from '../config/db.js';
import { signAccess, signRefresh, verifyRefresh, authenticate } from '../middleware/auth.js';
import { cacheDel } from '../config/redis.js';
import { logger } from '../utils/logger.js';

export default async function authRoutes(fastify) {

  // ---- POST /auth/login ----
  fastify.post('/login', {
    schema: {
      body: {
        type: 'object',
        required: ['email', 'password'],
        properties: {
          email:    { type: 'string', format: 'email' },
          password: { type: 'string', minLength: 1 },
        }
      }
    }
  }, async (req, reply) => {
    const { email, password } = req.body;

    const { rows } = await query(
      'SELECT id, username, email, password_hash, role, status, two_fa_enabled, login_attempts, locked_until FROM users WHERE email = $1',
      [email.toLowerCase()]
    );

    const user = rows[0];

    // Constant-time comparison to prevent user enumeration
    const dummyHash = '$2a$12$invalidhashtopreventtimingattack123456789012';
    const hash = user?.password_hash || dummyHash;
    const valid = await bcrypt.compare(password, hash);

    if (!user || !valid) {
      // Increment failed attempts if user exists
      if (user) {
        await query(
          `UPDATE users SET
            login_attempts = login_attempts + 1,
            locked_until = CASE WHEN login_attempts >= 4 THEN NOW() + INTERVAL '15 minutes' ELSE locked_until END
          WHERE id = $1`,
          [user.id]
        );
      }
      return reply.code(401).send({ error: 'Invalid credentials' });
    }

    if (user.status === 'suspended') return reply.code(403).send({ error: 'Account suspended' });
    if (user.status === 'deleted')   return reply.code(401).send({ error: 'Account not found' });
    if (user.locked_until && new Date(user.locked_until) > new Date()) {
      return reply.code(429).send({ error: 'Account temporarily locked. Try again later.' });
    }

    // Reset failed attempts on success
    await query(
      'UPDATE users SET login_attempts = 0, locked_until = NULL, last_login_at = NOW(), last_login_ip = $2 WHERE id = $1',
      [user.id, req.ip]
    );

    const tokenPayload = { sub: user.id, role: user.role };
    const accessToken  = signAccess(tokenPayload);
    const refreshToken = signRefresh(tokenPayload);

    // Persist refresh token hash
    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await query(
      'INSERT INTO refresh_tokens (user_id, token_hash, ip, user_agent, expires_at) VALUES ($1,$2,$3,$4,$5)',
      [user.id, tokenHash, req.ip, req.headers['user-agent'], expiresAt]
    );

    // Audit
    await query(
      "INSERT INTO audit_log (user_id, action, ip, user_agent) VALUES ($1,'login',$2,$3)",
      [user.id, req.ip, req.headers['user-agent']]
    );

    logger.info({ userId: user.id, role: user.role }, 'User logged in');

    return reply.send({
      accessToken,
      refreshToken,
      user: { id: user.id, username: user.username, email: user.email, role: user.role }
    });
  });


  // ---- POST /auth/refresh ----
  fastify.post('/refresh', async (req, reply) => {
    const { refreshToken } = req.body || {};
    if (!refreshToken) return reply.code(400).send({ error: 'refreshToken required' });

    let payload;
    try {
      payload = verifyRefresh(refreshToken);
    } catch {
      return reply.code(401).send({ error: 'Invalid or expired refresh token' });
    }

    const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
    const { rows } = await query(
      'SELECT id, user_id, expires_at, revoked_at FROM refresh_tokens WHERE token_hash = $1',
      [tokenHash]
    );

    const stored = rows[0];
    if (!stored || stored.revoked_at || new Date(stored.expires_at) < new Date()) {
      return reply.code(401).send({ error: 'Refresh token invalid or expired' });
    }

    // Rotate: revoke old, issue new
    await query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE id = $1', [stored.id]);

    const newAccess  = signAccess({ sub: payload.sub, role: payload.role });
    const newRefresh = signRefresh({ sub: payload.sub, role: payload.role });
    const newHash    = crypto.createHash('sha256').update(newRefresh).digest('hex');
    const expiresAt  = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await query(
      'INSERT INTO refresh_tokens (user_id, token_hash, ip, user_agent, expires_at) VALUES ($1,$2,$3,$4,$5)',
      [stored.user_id, newHash, req.ip, req.headers['user-agent'], expiresAt]
    );

    return reply.send({ accessToken: newAccess, refreshToken: newRefresh });
  });


  // ---- POST /auth/logout ----
  fastify.post('/logout', { preHandler: authenticate }, async (req, reply) => {
    const { refreshToken } = req.body || {};
    if (refreshToken) {
      const tokenHash = crypto.createHash('sha256').update(refreshToken).digest('hex');
      await query('UPDATE refresh_tokens SET revoked_at = NOW() WHERE token_hash = $1', [tokenHash]);
    }
    // Invalidate user cache
    await cacheDel(`sf:user:${req.user.id}:info`);
    await query("INSERT INTO audit_log (user_id, action, ip) VALUES ($1,'logout',$2)", [req.user.id, req.ip]);
    return reply.send({ ok: true });
  });


  // ---- GET /auth/me ----
  fastify.get('/me', { preHandler: authenticate }, async (req, reply) => {
    const { rows } = await query(
      `SELECT id, username, email, role, status, display_name, avatar_color,
              max_viewers, max_streams, max_bitrate_kbps, storage_mb, traffic_mb_month,
              allow_youtube, allow_facebook, allow_twitch, allow_tiktok, allow_custom_rtmp,
              two_fa_enabled, last_login_at, created_at
       FROM users WHERE id = $1`,
      [req.user.id]
    );
    return reply.send(rows[0]);
  });


  // ---- POST /auth/change-password ----
  fastify.post('/change-password', { preHandler: authenticate }, async (req, reply) => {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) return reply.code(400).send({ error: 'Both passwords required' });
    if (newPassword.length < 12) return reply.code(400).send({ error: 'Password must be at least 12 characters' });

    const { rows } = await query('SELECT password_hash FROM users WHERE id=$1', [req.user.id]);
    const valid = await bcrypt.compare(currentPassword, rows[0].password_hash);
    if (!valid) return reply.code(401).send({ error: 'Current password incorrect' });

    const hash = await bcrypt.hash(newPassword, 12);
    await query('UPDATE users SET password_hash=$1 WHERE id=$2', [hash, req.user.id]);

    // Revoke all refresh tokens
    await query('UPDATE refresh_tokens SET revoked_at=NOW() WHERE user_id=$1 AND revoked_at IS NULL', [req.user.id]);
    await cacheDel(`sf:user:${req.user.id}:info`);

    await query("INSERT INTO audit_log (user_id,action,ip) VALUES ($1,'password_changed',$2)", [req.user.id, req.ip]);
    return reply.send({ ok: true });
  });
}
