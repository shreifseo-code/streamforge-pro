import bcrypt from 'bcryptjs';
import { query } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { cacheDel } from '../config/redis.js';

export default async function userRoutes(fastify) {

  // ---- GET /users ----
  fastify.get('/', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { role, status, page = 1, limit = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const conds = [], params = [];

    if (role)   { params.push(role);   conds.push(`role=$${params.length}`); }
    if (status) { params.push(status); conds.push(`status=$${params.length}`); }

    const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';

    const [dataRes, countRes] = await Promise.all([
      query(`
        SELECT id, username, email, role, status, display_name, avatar_color,
               max_viewers, max_streams, max_bitrate_kbps, storage_mb, traffic_mb_month,
               allow_youtube, allow_facebook, allow_twitch, allow_tiktok, allow_custom_rtmp,
               last_login_at, created_at,
               (SELECT COUNT(*) FROM streams WHERE user_id=users.id AND status='live') AS live_streams,
               (SELECT COUNT(*) FROM streams WHERE user_id=users.id) AS total_streams
        FROM users ${where}
        ORDER BY created_at DESC
        LIMIT $${params.length+1} OFFSET $${params.length+2}
      `, [...params, parseInt(limit), offset]),
      query(`SELECT COUNT(*) FROM users ${where}`, params)
    ]);

    return reply.send({
      users:  dataRes.rows,
      total:  parseInt(countRes.rows[0].count),
      page:   parseInt(page),
      limit:  parseInt(limit),
      pages:  Math.ceil(parseInt(countRes.rows[0].count) / parseInt(limit))
    });
  });

  // ---- POST /users ----
  fastify.post('/', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { username, email, password, role='broadcaster', display_name,
            max_viewers=500, max_streams=3, max_bitrate_kbps=6000,
            storage_mb=10240, traffic_mb_month=102400,
            allow_youtube=false, allow_facebook=false, allow_twitch=false,
            allow_tiktok=false, allow_custom_rtmp=false } = req.body;

    if (!username || !email || !password) {
      return reply.code(400).send({ error: 'username, email, password required' });
    }
    if (password.length < 12) {
      return reply.code(400).send({ error: 'Password must be at least 12 characters' });
    }

    // Prevent privilege escalation
    if (role === 'superadmin' && req.user.role !== 'superadmin') {
      return reply.code(403).send({ error: 'Cannot create superadmin' });
    }

    const hash = await bcrypt.hash(password, 12);

    try {
      const { rows } = await query(
        `INSERT INTO users
          (username, email, password_hash, role, display_name,
           max_viewers, max_streams, max_bitrate_kbps, storage_mb, traffic_mb_month,
           allow_youtube, allow_facebook, allow_twitch, allow_tiktok, allow_custom_rtmp,
           created_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
         RETURNING id, username, email, role, status, created_at`,
        [username, email.toLowerCase(), hash, role, display_name||username,
         max_viewers, max_streams, max_bitrate_kbps, storage_mb, traffic_mb_month,
         allow_youtube, allow_facebook, allow_twitch, allow_tiktok, allow_custom_rtmp,
         req.user.id]
      );
      await query(
        "INSERT INTO audit_log(user_id,action,entity,entity_id,ip) VALUES($1,'user_created','user',$2,$3)",
        [req.user.id, rows[0].id, req.ip]
      );
      return reply.code(201).send(rows[0]);
    } catch (err) {
      if (err.code === '23505') {
        return reply.code(409).send({ error: 'Username or email already exists' });
      }
      throw err;
    }
  });

  // ---- GET /users/:id ----
  fastify.get('/:id', { preHandler: authenticate }, async (req, reply) => {
    if (req.user.role === 'broadcaster' && req.user.id !== req.params.id) {
      return reply.code(403).send({ error: 'Access denied' });
    }
    const { rows } = await query(
      `SELECT id, username, email, role, status, display_name, avatar_color,
              max_viewers, max_streams, max_bitrate_kbps, storage_mb, traffic_mb_month,
              allow_youtube, allow_facebook, allow_twitch, allow_tiktok, allow_custom_rtmp,
              two_fa_enabled, last_login_at, last_login_ip, created_at
       FROM users WHERE id=$1`,
      [req.params.id]
    );
    if (!rows.length) return reply.code(404).send({ error: 'User not found' });
    return reply.send(rows[0]);
  });

  // ---- PATCH /users/:id ----
  fastify.patch('/:id', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const allowed = ['display_name','avatar_color','max_viewers','max_streams','max_bitrate_kbps',
                     'storage_mb','traffic_mb_month','allow_youtube','allow_facebook',
                     'allow_twitch','allow_tiktok','allow_custom_rtmp'];
    const fields = [], params = [];
    for (const k of allowed) {
      if (req.body[k] !== undefined) {
        params.push(req.body[k]);
        fields.push(`${k}=$${params.length}`);
      }
    }
    if (!fields.length) return reply.code(400).send({ error: 'Nothing to update' });
    params.push(req.params.id);
    const { rows } = await query(
      `UPDATE users SET ${fields.join(',')} WHERE id=$${params.length} RETURNING id,username,email,role,status`,
      params
    );
    if (!rows.length) return reply.code(404).send({ error: 'User not found' });
    await cacheDel(`sf:user:${req.params.id}:info`);
    await query(
      "INSERT INTO audit_log(user_id,action,entity,entity_id,ip) VALUES($1,'user_updated','user',$2,$3)",
      [req.user.id, req.params.id, req.ip]
    );
    return reply.send(rows[0]);
  });

  // ---- POST /users/:id/suspend ----
  fastify.post('/:id/suspend', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    if (req.params.id === req.user.id) return reply.code(400).send({ error: 'Cannot suspend yourself' });
    await query("UPDATE users SET status='suspended' WHERE id=$1", [req.params.id]);
    await cacheDel(`sf:user:${req.params.id}:info`);
    // Also idle all their streams
    await query("UPDATE streams SET status='idle' WHERE user_id=$1 AND status='live'", [req.params.id]);
    await query(
      "INSERT INTO audit_log(user_id,action,entity,entity_id,ip,payload) VALUES($1,'user_suspended','user',$2,$3,$4)",
      [req.user.id, req.params.id, req.ip, JSON.stringify({ reason: req.body?.reason })]
    );
    return reply.send({ ok: true });
  });

  // ---- POST /users/:id/unsuspend ----
  fastify.post('/:id/unsuspend', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    await query("UPDATE users SET status='active' WHERE id=$1 AND status='suspended'", [req.params.id]);
    await cacheDel(`sf:user:${req.params.id}:info`);
    return reply.send({ ok: true });
  });

  // ---- DELETE /users/:id ----
  fastify.delete('/:id', {
    preHandler: [authenticate, requireRole('superadmin')]
  }, async (req, reply) => {
    if (req.params.id === req.user.id) return reply.code(400).send({ error: 'Cannot delete yourself' });
    // Soft delete
    await query("UPDATE users SET status='deleted', email=email||'_deleted_'||id WHERE id=$1", [req.params.id]);
    await cacheDel(`sf:user:${req.params.id}:info`);
    await query(
      "INSERT INTO audit_log(user_id,action,entity,entity_id,ip) VALUES($1,'user_deleted','user',$2,$3)",
      [req.user.id, req.params.id, req.ip]
    );
    return reply.code(204).send();
  });

  // ---- POST /users/:id/login-as (impersonate) ----
  fastify.post('/:id/login-as', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query('SELECT id, username, email, role, status FROM users WHERE id=$1', [req.params.id]);
    if (!rows.length) return reply.code(404).send({ error: 'User not found' });
    const target = rows[0];
    if (target.status !== 'active') return reply.code(400).send({ error: 'User not active' });

    const { signAccess } = await import('../middleware/auth.js');
    const token = signAccess({ sub: target.id, role: target.role, impersonatedBy: req.user.id });
    await query(
      "INSERT INTO audit_log(user_id,action,entity,entity_id,ip,payload) VALUES($1,'login_as','user',$2,$3,$4)",
      [req.user.id, target.id, req.ip, JSON.stringify({ targetUser: target.username })]
    );
    return reply.send({ accessToken: token, user: target });
  });

  // ---- GET /users/:id/streams ----
  fastify.get('/:id/streams', { preHandler: authenticate }, async (req, reply) => {
    if (req.user.role === 'broadcaster' && req.user.id !== req.params.id) {
      return reply.code(403).send({ error: 'Access denied' });
    }
    const { rows } = await query(
      `SELECT s.id, s.name, s.stream_type, s.status, s.current_viewers, s.current_bitrate_kbps,
              s.started_at, s.stream_key, n.name AS node_name
       FROM streams s LEFT JOIN edge_nodes n ON s.node_id=n.id
       WHERE s.user_id=$1 ORDER BY s.updated_at DESC`,
      [req.params.id]
    );
    return reply.send({ streams: rows, total: rows.length });
  });
}
