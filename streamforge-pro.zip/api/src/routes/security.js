import { query } from '../config/db.js';
import { authenticate, requireRole } from '../middleware/auth.js';
import { cacheSet, cacheDel_pattern } from '../config/redis.js';
import { logger } from '../utils/logger.js';

export default async function securityRoutes(fastify) {

  // ---- GET /security/settings ----
  fastify.get('/settings', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query("SELECT value FROM settings WHERE key='security'");
    return reply.send(rows[0]?.value || {});
  });

  // ---- PATCH /security/settings ----
  fastify.patch('/settings', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    await query(
      `INSERT INTO settings (key, value, updated_by) VALUES ('security',$1,$2)
       ON CONFLICT (key) DO UPDATE SET value=$1, updated_by=$2, updated_at=NOW()`,
      [JSON.stringify(req.body), req.user.id]
    );
    await cacheDel_pattern('sf:security:*');
    return reply.send({ ok: true });
  });

  // ---- GET /security/geo-rules ----
  fastify.get('/geo-rules', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query(
      `SELECT g.*, s.name AS stream_name, u.username
       FROM geo_rules g
       LEFT JOIN streams s ON g.stream_id=s.id
       LEFT JOIN users u ON g.user_id=u.id
       ORDER BY g.created_at DESC`
    );
    return reply.send({ rules: rows });
  });

  // ---- POST /security/geo-rules ----
  fastify.post('/geo-rules', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { country_code, action, stream_id, user_id } = req.body;
    if (!country_code || !action) return reply.code(400).send({ error: 'country_code and action required' });
    if (!['allow','block'].includes(action)) return reply.code(400).send({ error: 'action must be allow or block' });

    const { rows } = await query(
      'INSERT INTO geo_rules (country_code, action, stream_id, user_id) VALUES ($1,$2,$3,$4) RETURNING *',
      [country_code.toUpperCase(), action, stream_id || null, user_id || null]
    );
    await cacheDel_pattern('sf:geo:*');
    return reply.code(201).send(rows[0]);
  });

  // ---- DELETE /security/geo-rules/:id ----
  fastify.delete('/geo-rules/:id', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    await query('DELETE FROM geo_rules WHERE id=$1', [req.params.id]);
    await cacheDel_pattern('sf:geo:*');
    return reply.code(204).send();
  });

  // ---- GET /security/blocklist ----
  fastify.get('/blocklist', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query(
      `SELECT b.*, u.username AS blocked_by_user
       FROM ip_blocklist b LEFT JOIN users u ON b.blocked_by=u.id
       ORDER BY b.created_at DESC`
    );
    return reply.send({ blocked: rows });
  });

  // ---- POST /security/blocklist ----
  fastify.post('/blocklist', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { cidr, reason, expires_hours } = req.body;
    if (!cidr) return reply.code(400).send({ error: 'cidr required (e.g. 1.2.3.4/32)' });

    const expires_at = expires_hours
      ? new Date(Date.now() + expires_hours * 3600 * 1000)
      : null;

    try {
      const { rows } = await query(
        'INSERT INTO ip_blocklist (cidr, reason, blocked_by, expires_at) VALUES ($1,$2,$3,$4) RETURNING *',
        [cidr, reason, req.user.id, expires_at]
      );
      // Cache for fast lookup
      await cacheSet(`sf:block:ip:${cidr}`, { blocked: true, reason }, expires_hours ? expires_hours * 3600 : 86400);
      logger.info({ cidr, blockedBy: req.user.username }, 'IP blocked');
      return reply.code(201).send(rows[0]);
    } catch (err) {
      if (err.code === '23505') return reply.code(409).send({ error: 'CIDR already blocked' });
      if (err.code === '22P02') return reply.code(400).send({ error: 'Invalid CIDR format' });
      throw err;
    }
  });

  // ---- DELETE /security/blocklist/:id ----
  fastify.delete('/blocklist/:id', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rows } = await query('DELETE FROM ip_blocklist WHERE id=$1 RETURNING cidr', [req.params.id]);
    if (rows.length) await cacheDel_pattern(`sf:block:ip:${rows[0].cidr}`);
    return reply.code(204).send();
  });

  // ---- GET /security/alerts ----
  fastify.get('/alerts', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { resolved = false, limit = 50 } = req.query;
    const { rows } = await query(
      `SELECT * FROM alerts WHERE resolved=$1 ORDER BY created_at DESC LIMIT $2`,
      [resolved === 'true', parseInt(limit)]
    );
    return reply.send({ alerts: rows });
  });

  // ---- PATCH /security/alerts/:id/resolve ----
  fastify.patch('/alerts/:id/resolve', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    await query(
      "UPDATE alerts SET resolved=true, resolved_at=NOW() WHERE id=$1",
      [req.params.id]
    );
    return reply.send({ ok: true });
  });

  // ---- GET /security/audit-log ----
  fastify.get('/audit-log', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { user_id, action, page = 1, limit = 50 } = req.query;
    const offset = (parseInt(page)-1) * parseInt(limit);
    const conds = [], params = [];

    if (user_id) { params.push(user_id); conds.push(`a.user_id=$${params.length}`); }
    if (action)  { params.push(action);  conds.push(`a.action=$${params.length}`);  }

    const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';

    const { rows } = await query(
      `SELECT a.*, u.username, u.email
       FROM audit_log a LEFT JOIN users u ON a.user_id=u.id
       ${where}
       ORDER BY a.created_at DESC
       LIMIT $${params.length+1} OFFSET $${params.length+2}`,
      [...params, parseInt(limit), offset]
    );
    return reply.send({ log: rows });
  });

  // ---- POST /security/stream/:id/rotate-key (forced rotation on breach) ----
  fastify.post('/stream/:id/force-rotate', {
    preHandler: [authenticate, requireRole('superadmin','admin')]
  }, async (req, reply) => {
    const { rotateStreamKey } = await import('../services/streamService.js');
    const stream = await rotateStreamKey(req.params.id);

    await query(
      `INSERT INTO alerts (severity, title, body, source, entity_id, entity_type)
       VALUES ('warning', $1, $2, 'admin', $3, 'stream')`,
      [
        `Stream key force-rotated by ${req.user.username}`,
        `Old key invalidated. New key: ${stream.stream_key}`,
        req.params.id
      ]
    );
    return reply.send({ ok: true, newKey: stream.stream_key });
  });
}
