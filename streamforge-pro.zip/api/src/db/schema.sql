-- ============================================================
-- StreamForge Pro — Database Schema
-- PostgreSQL 15+
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUMS
-- ============================================================

CREATE TYPE user_role AS ENUM ('superadmin', 'admin', 'broadcaster');
CREATE TYPE user_status AS ENUM ('active', 'suspended', 'pending', 'deleted');
CREATE TYPE stream_type AS ENUM ('rtmp_push', 'iptv_pull', 'hls_pull');
CREATE TYPE stream_status AS ENUM ('live', 'idle', 'error', 'disabled');
CREATE TYPE node_status AS ENUM ('online', 'offline', 'maintenance', 'draining');
CREATE TYPE alert_severity AS ENUM ('info', 'warning', 'error', 'critical');

-- ============================================================
-- USERS
-- ============================================================

CREATE TABLE users (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username       VARCHAR(64) UNIQUE NOT NULL,
  email          VARCHAR(255) UNIQUE NOT NULL,
  password_hash  TEXT NOT NULL,
  role           user_role NOT NULL DEFAULT 'broadcaster',
  status         user_status NOT NULL DEFAULT 'active',
  display_name   VARCHAR(128),
  avatar_color   VARCHAR(7) DEFAULT '#00d4ff',

  -- Limits (0 = unlimited)
  max_viewers    INTEGER NOT NULL DEFAULT 500,
  max_streams    INTEGER NOT NULL DEFAULT 3,
  max_bitrate_kbps INTEGER NOT NULL DEFAULT 6000,
  storage_mb     BIGINT NOT NULL DEFAULT 10240,
  traffic_mb_month BIGINT NOT NULL DEFAULT 102400,

  -- Social streaming permissions
  allow_youtube    BOOLEAN DEFAULT FALSE,
  allow_facebook   BOOLEAN DEFAULT FALSE,
  allow_twitch     BOOLEAN DEFAULT FALSE,
  allow_tiktok     BOOLEAN DEFAULT FALSE,
  allow_custom_rtmp BOOLEAN DEFAULT FALSE,

  -- Auth
  two_fa_enabled  BOOLEAN DEFAULT FALSE,
  two_fa_secret   TEXT,
  last_login_at   TIMESTAMPTZ,
  last_login_ip   INET,
  login_attempts  INTEGER DEFAULT 0,
  locked_until    TIMESTAMPTZ,

  created_by     UUID REFERENCES users(id) ON DELETE SET NULL,
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_status ON users(status);

-- ============================================================
-- REFRESH TOKENS
-- ============================================================

CREATE TABLE refresh_tokens (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash TEXT NOT NULL UNIQUE,
  ip         INET,
  user_agent TEXT,
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_expires ON refresh_tokens(expires_at);

-- ============================================================
-- EDGE SERVERS (Nodes)
-- ============================================================

CREATE TABLE edge_nodes (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         VARCHAR(64) NOT NULL UNIQUE,
  region       VARCHAR(64) NOT NULL,
  country_code CHAR(2),
  flag_emoji   VARCHAR(8),
  ip_address   INET NOT NULL,
  rtmp_port    INTEGER NOT NULL DEFAULT 1935,
  hls_port     INTEGER NOT NULL DEFAULT 8080,
  api_port     INTEGER NOT NULL DEFAULT 9090,
  api_secret   TEXT NOT NULL DEFAULT encode(gen_random_bytes(32), 'hex'),
  is_origin    BOOLEAN DEFAULT FALSE,
  status       node_status NOT NULL DEFAULT 'online',
  max_streams  INTEGER DEFAULT 100,
  max_bw_gbps  NUMERIC(5,2) DEFAULT 10.0,

  -- Live metrics (updated by heartbeat)
  cpu_pct       NUMERIC(5,2),
  ram_pct       NUMERIC(5,2),
  bw_out_mbps   NUMERIC(10,2),
  active_streams INTEGER DEFAULT 0,
  active_viewers INTEGER DEFAULT 0,
  latency_ms    INTEGER,
  last_ping_at  TIMESTAMPTZ,

  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- STREAMS
-- ============================================================

CREATE TABLE streams (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id      UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  node_id      UUID REFERENCES edge_nodes(id) ON DELETE SET NULL,

  name         VARCHAR(128) NOT NULL,
  description  TEXT,
  stream_type  stream_type NOT NULL DEFAULT 'rtmp_push',
  status       stream_status NOT NULL DEFAULT 'idle',

  -- RTMP push
  stream_key   VARCHAR(64) UNIQUE NOT NULL DEFAULT encode(gen_random_bytes(16), 'hex'),
  rtmp_url     TEXT GENERATED ALWAYS AS (
    'rtmp://' || '#{node_ip}' || '/live/' || stream_key
  ) STORED,

  -- Pull source (IPTV/HLS)
  source_url   TEXT,

  -- HLS output
  hls_url      TEXT,
  hls_qualities JSONB DEFAULT '["1080p","720p","480p","360p"]',

  -- Simulcast targets
  simulcast_targets JSONB DEFAULT '[]',

  -- Limits
  max_viewers  INTEGER DEFAULT 0,
  max_bitrate_kbps INTEGER DEFAULT 0,

  -- Security
  token_auth_enabled BOOLEAN DEFAULT TRUE,
  token_expiry_sec   INTEGER DEFAULT 3600,
  allowed_referrers  TEXT[] DEFAULT '{}',
  geo_allow          TEXT[] DEFAULT '{}',
  geo_block          TEXT[] DEFAULT '{}',

  -- Stats snapshot
  current_viewers  INTEGER DEFAULT 0,
  current_bitrate_kbps INTEGER DEFAULT 0,
  peak_viewers     INTEGER DEFAULT 0,
  total_bytes_out  BIGINT DEFAULT 0,

  started_at   TIMESTAMPTZ,
  ended_at     TIMESTAMPTZ,
  uptime_sec   INTEGER DEFAULT 0,

  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_streams_user ON streams(user_id);
CREATE INDEX idx_streams_status ON streams(status);
CREATE INDEX idx_streams_key ON streams(stream_key);
CREATE INDEX idx_streams_node ON streams(node_id);

-- ============================================================
-- STREAM EVENTS (audit trail for every stream lifecycle event)
-- ============================================================

CREATE TABLE stream_events (
  id        BIGSERIAL PRIMARY KEY,
  stream_id UUID NOT NULL REFERENCES streams(id) ON DELETE CASCADE,
  event     VARCHAR(64) NOT NULL,
  payload   JSONB,
  node_id   UUID REFERENCES edge_nodes(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_stream_events_stream ON stream_events(stream_id);
CREATE INDEX idx_stream_events_created ON stream_events(created_at DESC);

-- ============================================================
-- VIEWER STATS (time-series, 1-min resolution)
-- ============================================================

CREATE TABLE viewer_stats (
  id          BIGSERIAL PRIMARY KEY,
  stream_id   UUID NOT NULL REFERENCES streams(id) ON DELETE CASCADE,
  node_id     UUID REFERENCES edge_nodes(id),
  bucket      TIMESTAMPTZ NOT NULL,
  viewers     INTEGER DEFAULT 0,
  bitrate_kbps INTEGER DEFAULT 0,
  bytes_out   BIGINT DEFAULT 0,
  UNIQUE(stream_id, node_id, bucket)
);

CREATE INDEX idx_viewer_stats_stream ON viewer_stats(stream_id, bucket DESC);
CREATE INDEX idx_viewer_stats_bucket ON viewer_stats(bucket DESC);

-- ============================================================
-- BANDWIDTH USAGE (per-user monthly aggregation)
-- ============================================================

CREATE TABLE bandwidth_usage (
  id          BIGSERIAL PRIMARY KEY,
  user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  year_month  CHAR(7) NOT NULL,
  bytes_out   BIGINT DEFAULT 0,
  bytes_in    BIGINT DEFAULT 0,
  UNIQUE(user_id, year_month)
);

-- ============================================================
-- SYSTEM ALERTS
-- ============================================================

CREATE TABLE alerts (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  severity   alert_severity NOT NULL DEFAULT 'info',
  title      TEXT NOT NULL,
  body       TEXT,
  source     VARCHAR(128),
  entity_id  UUID,
  entity_type VARCHAR(64),
  resolved   BOOLEAN DEFAULT FALSE,
  resolved_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_alerts_resolved ON alerts(resolved, created_at DESC);

-- ============================================================
-- IP BLOCKLIST
-- ============================================================

CREATE TABLE ip_blocklist (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  cidr       CIDR NOT NULL UNIQUE,
  reason     TEXT,
  blocked_by UUID REFERENCES users(id),
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- GEO RULES
-- ============================================================

CREATE TABLE geo_rules (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  stream_id    UUID REFERENCES streams(id) ON DELETE CASCADE,
  user_id      UUID REFERENCES users(id) ON DELETE CASCADE,
  country_code CHAR(2) NOT NULL,
  action       VARCHAR(8) NOT NULL CHECK (action IN ('allow','block')),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(stream_id, country_code),
  CHECK (stream_id IS NOT NULL OR user_id IS NOT NULL)
);

-- ============================================================
-- AUDIT LOG
-- ============================================================

CREATE TABLE audit_log (
  id         BIGSERIAL PRIMARY KEY,
  user_id    UUID REFERENCES users(id) ON DELETE SET NULL,
  action     VARCHAR(128) NOT NULL,
  entity     VARCHAR(64),
  entity_id  UUID,
  ip         INET,
  user_agent TEXT,
  payload    JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_log_user ON audit_log(user_id, created_at DESC);
CREATE INDEX idx_audit_log_created ON audit_log(created_at DESC);

-- ============================================================
-- SYSTEM SETTINGS
-- ============================================================

CREATE TABLE settings (
  key        VARCHAR(128) PRIMARY KEY,
  value      JSONB NOT NULL,
  updated_by UUID REFERENCES users(id),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TRIGGERS: updated_at auto-update
-- ============================================================

CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER users_updated_at
  BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER streams_updated_at
  BEFORE UPDATE ON streams FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER edge_nodes_updated_at
  BEFORE UPDATE ON edge_nodes FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ============================================================
-- SEED: default superadmin
-- ============================================================

INSERT INTO users (username, email, password_hash, role, display_name, max_viewers, max_streams, max_bitrate_kbps, storage_mb, traffic_mb_month)
VALUES (
  'admin',
  'admin@streamforge.local',
  crypt('Admin@StreamForge2025!', gen_salt('bf', 12)),
  'superadmin',
  'Super Admin',
  0, 0, 0, 0, 0
);

INSERT INTO settings (key, value) VALUES
  ('smtp',           '{"host":"","port":587,"user":"","tls":true}'),
  ('branding',       '{"company":"StreamForge Pro","logo":"","primaryColor":"#00d4ff"}'),
  ('security',       '{"tokenAuth":true,"tokenExpiry":3600,"rateLimit":200,"autoRotateKey":true}'),
  ('notifications',  '{"streamDown":true,"highLoad":true,"bandwidth":true}');

-- ============================================================
-- VIEWS
-- ============================================================

CREATE VIEW v_live_streams AS
SELECT
  s.id, s.name, s.stream_key, s.stream_type, s.status,
  s.current_viewers, s.current_bitrate_kbps, s.peak_viewers,
  s.started_at,
  EXTRACT(EPOCH FROM (NOW() - s.started_at))::INT AS uptime_sec,
  u.username, u.email,
  n.name AS node_name, n.region, n.ip_address
FROM streams s
JOIN users u ON s.user_id = u.id
LEFT JOIN edge_nodes n ON s.node_id = n.id
WHERE s.status = 'live';

CREATE VIEW v_dashboard_stats AS
SELECT
  (SELECT COUNT(*) FROM streams WHERE status = 'live')         AS live_streams,
  (SELECT COALESCE(SUM(current_viewers),0) FROM streams WHERE status='live') AS total_viewers,
  (SELECT COALESCE(SUM(current_bitrate_kbps),0)/1024.0/1024 FROM streams WHERE status='live') AS total_gbps,
  (SELECT COUNT(*) FROM edge_nodes WHERE status = 'online')    AS nodes_online,
  (SELECT COUNT(*) FROM edge_nodes)                            AS nodes_total,
  (SELECT COUNT(*) FROM users WHERE status = 'active' AND role = 'broadcaster') AS active_broadcasters;
