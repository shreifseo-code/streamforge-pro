import { query, transaction } from '../config/db.js';
import { cacheGet, cacheSet, cacheDel, cacheDel_pattern, publish, KEYS } from '../config/redis.js';
import { nanoid } from 'nanoid';
import crypto from 'crypto';
import { logger } from '../utils/logger.js';

const STREAM_TOKEN_SECRET = process.env.STREAM_TOKEN_SECRET || 'change_me';

// ---- Stream Key Generation ----

export function generateStreamKey() {
  return nanoid(24);
}

// ---- Signed HLS token (anti-leech) ----

export function generateViewToken(streamId, ttlSec = 3600) {
  const exp = Math.floor(Date.now() / 1000) + ttlSec;
  const payload = `${streamId}:${exp}`;
  const sig = crypto
    .createHmac('sha256', STREAM_TOKEN_SECRET)
    .update(payload)
    .digest('hex')
    .slice(0, 16);
  return { token: `${exp}.${sig}`, expires: exp };
}

export function verifyViewToken(streamId, tokenStr) {
  const parts = tokenStr.split('.');
  if (parts.length !== 2) return false;
  const [exp, sig] = parts;
  if (parseInt(exp) < Math.floor(Date.now() / 1000)) return false;
  const payload  = `${streamId}:${exp}`;
  const expected = crypto
    .createHmac('sha256', STREAM_TOKEN_SECRET)
    .update(payload)
    .digest('hex')
    .slice(0, 16);
  return crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(expected));
}

// ---- Create stream ----

export async function createStream(userId, data) {
  const streamKey = generateStreamKey();
  const node = await pickBestNode();

  const { rows } = await query(
    `INSERT INTO streams
      (user_id, node_id, name, description, stream_type, stream_key,
       source_url, hls_qualities, max_viewers, max_bitrate_kbps,
       token_auth_enabled, token_expiry_sec, allowed_referrers, geo_allow, geo_block)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
     RETURNING *`,
    [
      userId, node?.id, data.name, data.description || null,
      data.stream_type || 'rtmp_push', streamKey,
      data.source_url || null,
      JSON.stringify(data.hls_qualities || ['1080p','720p','480p','360p']),
      data.max_viewers || 0, data.max_bitrate_kbps || 0,
      data.token_auth_enabled !== false,
      data.token_expiry_sec || 3600,
      data.allowed_referrers || [],
      data.geo_allow || [], data.geo_block || []
    ]
  );

  const stream = rows[0];

  // Build RTMP info
  stream.rtmp_ingest = node
    ? `rtmp://${node.ip_address}:${node.rtmp_port}/live/${streamKey}`
    : `rtmp://${process.env.RTMP_HOST || 'origin'}:1935/live/${streamKey}`;

  stream.hls_playback = node
    ? `${process.env.HLS_BASE_URL || 'https://hls.streamforge.local'}/live/${streamKey}/index.m3u8`
    : null;

  await query(
    "INSERT INTO stream_events (stream_id, event, payload) VALUES ($1,'created',$2)",
    [stream.id, JSON.stringify({ userId, nodeId: node?.id })]
  );

  logger.info({ streamId: stream.id, userId, key: streamKey }, 'Stream created');
  return stream;
}

// ---- Get streams (with pagination) ----

export async function listStreams({ userId, role, status, page = 1, limit = 20 }) {
  const offset = (page - 1) * limit;
  const conditions = [];
  const params = [];

  if (role === 'broadcaster') {
    params.push(userId);
    conditions.push(`s.user_id = $${params.length}`);
  }
  if (status) {
    params.push(status);
    conditions.push(`s.status = $${params.length}`);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const [dataRes, countRes] = await Promise.all([
    query(`
      SELECT s.*, u.username, u.email,
             n.name AS node_name, n.region, n.country_code, n.flag_emoji
      FROM streams s
      JOIN users u ON s.user_id = u.id
      LEFT JOIN edge_nodes n ON s.node_id = n.id
      ${where}
      ORDER BY s.updated_at DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `, [...params, limit, offset]),

    query(`SELECT COUNT(*) FROM streams s ${where}`, params)
  ]);

  return {
    streams: dataRes.rows,
    total:   parseInt(countRes.rows[0].count),
    page, limit,
    pages: Math.ceil(parseInt(countRes.rows[0].count) / limit)
  };
}

// ---- Get single stream ----

export async function getStream(streamId, userId, role) {
  const { rows } = await query(
    `SELECT s.*, u.username, u.email,
            n.name AS node_name, n.region, n.ip_address, n.rtmp_port, n.hls_port
     FROM streams s
     JOIN users u ON s.user_id = u.id
     LEFT JOIN edge_nodes n ON s.node_id = n.id
     WHERE s.id = $1`,
    [streamId]
  );

  if (!rows.length) return null;
  const stream = rows[0];
  if (role === 'broadcaster' && stream.user_id !== userId) return null;

  // Attach RTMP/HLS URLs
  if (stream.ip_address) {
    stream.rtmp_ingest  = `rtmp://${stream.ip_address}:${stream.rtmp_port || 1935}/live/${stream.stream_key}`;
    stream.hls_playback = `${process.env.HLS_BASE_URL}/live/${stream.stream_key}/index.m3u8`;
  }

  return stream;
}

// ---- Update stream ----

export async function updateStream(streamId, data) {
  const fields = [];
  const params = [];
  const allowed = ['name','description','max_viewers','max_bitrate_kbps','token_auth_enabled',
                   'token_expiry_sec','allowed_referrers','geo_allow','geo_block','source_url',
                   'hls_qualities','simulcast_targets'];

  for (const key of allowed) {
    if (data[key] !== undefined) {
      params.push(typeof data[key] === 'object' ? JSON.stringify(data[key]) : data[key]);
      fields.push(`${key} = $${params.length}`);
    }
  }

  if (!fields.length) return null;
  params.push(streamId);

  const { rows } = await query(
    `UPDATE streams SET ${fields.join(', ')}, updated_at=NOW() WHERE id=$${params.length} RETURNING *`,
    params
  );

  await cacheDel(`sf:stream:${streamId}:info`);
  return rows[0];
}

// ---- Delete stream ----

export async function deleteStream(streamId) {
  await query('DELETE FROM streams WHERE id=$1', [streamId]);
  await cacheDel_pattern(`sf:stream:${streamId}:*`);
}

// ---- Rotate stream key ----

export async function rotateStreamKey(streamId) {
  const newKey = generateStreamKey();
  const { rows } = await query(
    'UPDATE streams SET stream_key=$1, updated_at=NOW() WHERE id=$2 RETURNING *',
    [newKey, streamId]
  );
  await query(
    "INSERT INTO stream_events (stream_id, event, payload) VALUES ($1,'key_rotated',$2)",
    [streamId, JSON.stringify({ newKey })]
  );
  await cacheDel(`sf:stream:${streamId}:info`);
  logger.info({ streamId, newKey }, 'Stream key rotated');
  return rows[0];
}

// ---- RTMP hook: stream connected ----

export async function onStreamPublish(streamKey, nodeIp) {
  const { rows } = await query(
    `UPDATE streams SET status='live', started_at=NOW(), updated_at=NOW()
     WHERE stream_key=$1 AND status != 'disabled'
     RETURNING id, user_id, max_viewers, max_bitrate_kbps`,
    [streamKey]
  );

  if (!rows.length) {
    logger.warn({ streamKey, nodeIp }, 'Unknown stream key rejected');
    return { allow: false };
  }

  const stream = rows[0];
  await query(
    "INSERT INTO stream_events (stream_id, event, payload) VALUES ($1,'published',$2)",
    [stream.id, JSON.stringify({ nodeIp })]
  );
  await publish('stream:events', { type: 'published', streamId: stream.id });
  logger.info({ streamKey, streamId: stream.id }, 'Stream went live');
  return { allow: true, streamId: stream.id };
}

// ---- RTMP hook: stream disconnected ----

export async function onStreamDone(streamKey) {
  const { rows } = await query(
    `UPDATE streams SET
       status='idle', ended_at=NOW(),
       uptime_sec = EXTRACT(EPOCH FROM (NOW() - started_at))::INT,
       current_viewers=0, current_bitrate_kbps=0,
       updated_at=NOW()
     WHERE stream_key=$1
     RETURNING id, peak_viewers, uptime_sec`,
    [streamKey]
  );
  if (!rows.length) return;
  const stream = rows[0];

  await query(
    "INSERT INTO stream_events (stream_id, event, payload) VALUES ($1,'done',$2)",
    [stream.id, JSON.stringify({ uptime: stream.uptime_sec, peakViewers: stream.peak_viewers })]
  );
  await publish('stream:events', { type: 'done', streamId: stream.id });
  logger.info({ streamKey, streamId: stream.id }, 'Stream ended');
}

// ---- Pick best edge node (lowest load) ----

export async function pickBestNode() {
  const { rows } = await query(
    `SELECT id, name, ip_address, rtmp_port, hls_port,
            cpu_pct, active_streams, max_streams
     FROM edge_nodes
     WHERE status = 'online'
     ORDER BY
       COALESCE(active_streams::float / NULLIF(max_streams,0), 0) ASC,
       COALESCE(cpu_pct, 0) ASC
     LIMIT 1`
  );
  return rows[0] || null;
}

// ---- Update viewer count from stats agent ----

export async function updateViewerCount(streamId, viewers, bitrateKbps) {
  await query(
    `UPDATE streams SET
       current_viewers=$2,
       current_bitrate_kbps=$3,
       peak_viewers=GREATEST(peak_viewers,$2),
       updated_at=NOW()
     WHERE id=$1`,
    [streamId, viewers, bitrateKbps]
  );

  // Time-series insert (1-min bucket)
  const bucket = new Date();
  bucket.setSeconds(0, 0);
  await query(
    `INSERT INTO viewer_stats (stream_id, bucket, viewers, bitrate_kbps)
     VALUES ($1,$2,$3,$4)
     ON CONFLICT (stream_id, node_id, bucket) DO UPDATE
       SET viewers=EXCLUDED.viewers, bitrate_kbps=EXCLUDED.bitrate_kbps`,
    [streamId, bucket, viewers, bitrateKbps]
  );
}

// ---- Live stats for dashboard ----

export async function getDashboardStats() {
  const cached = await cacheGet(KEYS.dashboardStats);
  if (cached) return cached;

  const { rows } = await query('SELECT * FROM v_dashboard_stats');
  const stats = rows[0];

  // Per-node load
  const nodeRes = await query(
    `SELECT id, name, region, country_code, flag_emoji, ip_address,
            status, cpu_pct, ram_pct, bw_out_mbps, active_streams,
            active_viewers, latency_ms, max_streams, last_ping_at
     FROM edge_nodes ORDER BY region`
  );
  stats.nodes = nodeRes.rows;

  // Recent alerts
  const alertRes = await query(
    `SELECT id, severity, title, body, source, created_at
     FROM alerts WHERE resolved=false
     ORDER BY created_at DESC LIMIT 10`
  );
  stats.alerts = alertRes.rows;

  await cacheSet(KEYS.dashboardStats, stats, 5);
  return stats;
}

// ---- Viewer history for a stream ----

export async function getViewerHistory(streamId, hours = 1) {
  const { rows } = await query(
    `SELECT bucket, viewers, bitrate_kbps
     FROM viewer_stats
     WHERE stream_id=$1 AND bucket > NOW() - ($2 || ' hours')::INTERVAL
     ORDER BY bucket ASC`,
    [streamId, hours]
  );
  return rows;
}
