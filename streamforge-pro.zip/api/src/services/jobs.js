import cron from 'node-cron';
import { query } from '../config/db.js';
import { cacheDel, cacheDel_pattern } from '../config/redis.js';
import { pingNode } from '../routes/servers.js';
import { logger } from '../utils/logger.js';

export function startJobs() {
  logger.info('Starting background jobs...');

  // ---- Node health check: every 30 seconds ----
  cron.schedule('*/30 * * * * *', async () => {
    try {
      const { rows: nodes } = await query(
        "SELECT * FROM edge_nodes WHERE status IN ('online','offline','draining')"
      );
      await Promise.allSettled(nodes.map(pingNode));
      await cacheDel('sf:stats:dashboard');
    } catch (err) {
      logger.error({ err }, 'Health check job failed');
    }
  });

  // ---- Bandwidth aggregation: every minute ----
  cron.schedule('* * * * *', async () => {
    try {
      const ym = new Date().toISOString().slice(0, 7);
      await query(`
        INSERT INTO bandwidth_usage (user_id, year_month, bytes_out)
        SELECT s.user_id, $1,
               COALESCE(SUM(vs.bytes_out), 0)
        FROM viewer_stats vs
        JOIN streams s ON vs.stream_id=s.id
        WHERE vs.bucket >= NOW() - INTERVAL '2 minutes'
          AND vs.bucket < NOW() - INTERVAL '1 minute'
        GROUP BY s.user_id
        ON CONFLICT (user_id, year_month)
        DO UPDATE SET bytes_out = bandwidth_usage.bytes_out + EXCLUDED.bytes_out
      `, [ym]);
    } catch (err) {
      logger.error({ err }, 'Bandwidth aggregation job failed');
    }
  });

  // ---- Auto-detect stale live streams: every 2 minutes ----
  // If a stream is "live" but has no viewer stats update in 3 min → mark as error
  cron.schedule('*/2 * * * *', async () => {
    try {
      const { rows } = await query(`
        UPDATE streams SET status='error', updated_at=NOW()
        WHERE status='live'
          AND updated_at < NOW() - INTERVAL '3 minutes'
        RETURNING id, stream_key
      `);
      for (const s of rows) {
        logger.warn({ streamId: s.id }, 'Stream auto-marked as error (stale)');
        await query(
          `INSERT INTO alerts (severity, title, source, entity_id, entity_type)
           VALUES ('error', $1, 'watchdog', $2, 'stream')`,
          [`Stream went stale: ${s.stream_key}`, s.id]
        );
        await query(
          "INSERT INTO stream_events (stream_id, event, payload) VALUES ($1,'stale',$2)",
          [s.id, JSON.stringify({ detectedBy: 'watchdog' })]
        );
      }
    } catch (err) {
      logger.error({ err }, 'Stale stream watchdog failed');
    }
  });

  // ---- Expired IP blocklist cleanup: every hour ----
  cron.schedule('0 * * * *', async () => {
    try {
      const { rowCount } = await query(
        'DELETE FROM ip_blocklist WHERE expires_at IS NOT NULL AND expires_at < NOW()'
      );
      if (rowCount > 0) logger.info({ removed: rowCount }, 'Expired IP blocks removed');
    } catch (err) {
      logger.error({ err }, 'IP blocklist cleanup failed');
    }
  });

  // ---- Expired refresh tokens cleanup: every 6 hours ----
  cron.schedule('0 */6 * * *', async () => {
    try {
      const { rowCount } = await query(
        'DELETE FROM refresh_tokens WHERE expires_at < NOW() OR revoked_at IS NOT NULL'
      );
      if (rowCount > 0) logger.info({ removed: rowCount }, 'Expired refresh tokens cleaned up');
    } catch (err) {
      logger.error({ err }, 'Token cleanup failed');
    }
  });

  // ---- Dashboard cache bust: every 5 seconds ----
  cron.schedule('*/5 * * * * *', async () => {
    await cacheDel('sf:stats:dashboard');
  });

  // ---- Old viewer_stats cleanup: keep 30 days ----
  cron.schedule('0 3 * * *', async () => {
    try {
      const { rowCount } = await query(
        "DELETE FROM viewer_stats WHERE bucket < NOW() - INTERVAL '30 days'"
      );
      logger.info({ removed: rowCount }, 'Old viewer stats pruned');
    } catch (err) {
      logger.error({ err }, 'Viewer stats cleanup failed');
    }
  });

  // ---- Old audit log: keep 90 days ----
  cron.schedule('0 4 * * *', async () => {
    try {
      const { rowCount } = await query(
        "DELETE FROM audit_log WHERE created_at < NOW() - INTERVAL '90 days'"
      );
      logger.info({ removed: rowCount }, 'Old audit log pruned');
    } catch (err) {
      logger.error({ err }, 'Audit log cleanup failed');
    }
  });

  logger.info('Background jobs started');
}
