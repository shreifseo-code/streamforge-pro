import { createClient } from 'redis';
import { logger } from '../utils/logger.js';

const client = createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379',
  password: process.env.REDIS_PASSWORD || undefined,
  socket: {
    reconnectStrategy: (retries) => {
      if (retries > 10) return new Error('Redis reconnect limit reached');
      return Math.min(retries * 100, 3000);
    }
  }
});

client.on('error', (err) => logger.error({ err }, 'Redis error'));
client.on('connect', () => logger.info('Redis connected'));
client.on('reconnecting', () => logger.warn('Redis reconnecting...'));

export async function connectRedis() {
  if (!client.isOpen) await client.connect();
  return client;
}

// ---- Helpers ----

export async function cacheSet(key, value, ttlSec = 60) {
  await client.set(key, JSON.stringify(value), { EX: ttlSec });
}

export async function cacheGet(key) {
  const data = await client.get(key);
  return data ? JSON.parse(data) : null;
}

export async function cacheDel(key) {
  await client.del(key);
}

export async function cacheDel_pattern(pattern) {
  const keys = await client.keys(pattern);
  if (keys.length > 0) await client.del(keys);
}

// ---- Pub/Sub for real-time stats ----

export async function publish(channel, message) {
  await client.publish(channel, JSON.stringify(message));
}

// ---- Stream metrics cache ----

export const KEYS = {
  dashboardStats:  'sf:stats:dashboard',
  streamViewers:   (id) => `sf:stream:${id}:viewers`,
  streamBitrate:   (id) => `sf:stream:${id}:bitrate`,
  nodeMetrics:     (id) => `sf:node:${id}:metrics`,
  userTokens:      (userId) => `sf:user:${userId}:tokens`,
  rateLimitStream: (ip)  => `sf:ratelimit:${ip}`,
  blacklistIP:     (ip)  => `sf:block:ip:${ip}`,
};

export default client;
