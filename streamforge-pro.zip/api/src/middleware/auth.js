import jwt from 'jsonwebtoken';
import { query } from '../config/db.js';
import { cacheGet, cacheSet, KEYS } from '../config/redis.js';

const ACCESS_SECRET  = process.env.JWT_SECRET;
const REFRESH_SECRET = process.env.JWT_SECRET + '_refresh';
const ACCESS_EXPIRY  = process.env.JWT_ACCESS_EXPIRY  || '15m';
const REFRESH_EXPIRY = process.env.JWT_REFRESH_EXPIRY || '7d';

// ---- Token generation ----

export function signAccess(payload) {
  return jwt.sign(payload, ACCESS_SECRET, { expiresIn: ACCESS_EXPIRY });
}

export function signRefresh(payload) {
  return jwt.sign(payload, REFRESH_SECRET, { expiresIn: REFRESH_EXPIRY });
}

export function verifyAccess(token) {
  return jwt.verify(token, ACCESS_SECRET);
}

export function verifyRefresh(token) {
  return jwt.verify(token, REFRESH_SECRET);
}

// ---- Fastify preHandler: authenticate ----

export async function authenticate(request, reply) {
  const auth = request.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) {
    return reply.code(401).send({ error: 'Missing Authorization header' });
  }

  const token = auth.slice(7);

  try {
    const payload = verifyAccess(token);

    // Quick cache lookup — avoid DB on every request
    const cached = await cacheGet(`sf:user:${payload.sub}:info`);
    if (cached) {
      request.user = cached;
      return;
    }

    // Fallback to DB
    const { rows } = await query(
      'SELECT id, username, email, role, status, max_viewers, max_streams FROM users WHERE id=$1',
      [payload.sub]
    );

    if (!rows.length) return reply.code(401).send({ error: 'User not found' });
    if (rows[0].status === 'suspended') return reply.code(403).send({ error: 'Account suspended' });
    if (rows[0].status === 'deleted')   return reply.code(401).send({ error: 'Account deleted' });

    await cacheSet(`sf:user:${payload.sub}:info`, rows[0], 300);
    request.user = rows[0];
  } catch (err) {
    if (err.name === 'TokenExpiredError') return reply.code(401).send({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    return reply.code(401).send({ error: 'Invalid token' });
  }
}

// ---- Role guard factory ----

export function requireRole(...roles) {
  return async function (request, reply) {
    if (!request.user) return reply.code(401).send({ error: 'Not authenticated' });
    if (!roles.includes(request.user.role)) {
      return reply.code(403).send({ error: 'Insufficient permissions', required: roles });
    }
  };
}

// ---- Ownership guard (broadcaster can only touch own resources) ----

export function requireOwnership(getResourceUserId) {
  return async function (request, reply) {
    const { user } = request;
    if (user.role === 'superadmin' || user.role === 'admin') return;

    const resourceUserId = await getResourceUserId(request);
    if (resourceUserId !== user.id) {
      return reply.code(403).send({ error: 'Access denied: not your resource' });
    }
  };
}
