import 'dotenv/config';
import Fastify from 'fastify';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import swagger from '@fastify/swagger';
import swaggerUi from '@fastify/swagger-ui';

import { checkConnection } from './config/db.js';
import { connectRedis } from './config/redis.js';
import { logger } from './utils/logger.js';
import { startJobs } from './services/jobs.js';

import authRoutes    from './routes/auth.js';
import streamRoutes  from './routes/streams.js';
import userRoutes    from './routes/users.js';
import serverRoutes  from './routes/servers.js';
import securityRoutes from './routes/security.js';

const PORT = parseInt(process.env.PORT || '3000');
const HOST = process.env.HOST || '0.0.0.0';

const fastify = Fastify({
  logger: false, // We use pino directly
  trustProxy: true,
  ajv: {
    customOptions: { removeAdditional: 'all', useDefaults: true, coerceTypes: true }
  }
});

// ---- Security headers ----
await fastify.register(helmet, {
  crossOriginResourcePolicy: { policy: 'cross-origin' },
  contentSecurityPolicy: false
});

// ---- CORS ----
await fastify.register(cors, {
  origin: process.env.NODE_ENV === 'production'
    ? (process.env.ALLOWED_ORIGINS || '').split(',')
    : true,
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS']
});

// ---- Rate limiting ----
await fastify.register(rateLimit, {
  max: parseInt(process.env.RATE_LIMIT_MAX || '200'),
  timeWindow: parseInt(process.env.RATE_LIMIT_WINDOW || '60000'),
  errorResponseBuilder: () => ({
    error: 'Rate limit exceeded',
    statusCode: 429,
    retryAfter: 60
  })
});

// ---- Swagger API docs ----
await fastify.register(swagger, {
  openapi: {
    info: { title: 'StreamForge Pro API', version: '1.0.0', description: 'Video streaming control panel API' },
    servers: [{ url: process.env.API_BASE_URL || 'http://localhost:3000' }],
    components: {
      securitySchemes: {
        bearerAuth: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' }
      }
    },
    security: [{ bearerAuth: [] }]
  }
});
await fastify.register(swaggerUi, { routePrefix: '/docs' });

// ---- Routes ----
fastify.register(authRoutes,    { prefix: '/api/v1/auth' });
fastify.register(streamRoutes,  { prefix: '/api/v1/streams' });
fastify.register(userRoutes,    { prefix: '/api/v1/users' });
fastify.register(serverRoutes,  { prefix: '/api/v1/servers' });
fastify.register(securityRoutes,{ prefix: '/api/v1/security' });

// ---- Health check ----
fastify.get('/health', async (req, reply) => {
  const db = await checkConnection().catch(() => null);
  return reply.send({
    status: db ? 'ok' : 'degraded',
    version: '1.0.0',
    time: new Date().toISOString(),
    db: !!db
  });
});

// ---- 404 ----
fastify.setNotFoundHandler((req, reply) => {
  reply.code(404).send({ error: `Route ${req.method} ${req.url} not found` });
});

// ---- Global error handler ----
fastify.setErrorHandler((err, req, reply) => {
  logger.error({ err, url: req.url, method: req.method }, 'Request error');

  if (err.validation) {
    return reply.code(400).send({ error: 'Validation error', details: err.validation });
  }
  if (err.statusCode) {
    return reply.code(err.statusCode).send({ error: err.message });
  }
  return reply.code(500).send({ error: 'Internal server error' });
});

// ---- Startup ----
async function start() {
  try {
    // Check dependencies
    const dbInfo = await checkConnection();
    logger.info({ pg: dbInfo.version.split(' ')[1] }, 'PostgreSQL connected');

    await connectRedis();

    // Start background jobs
    startJobs();

    await fastify.listen({ port: PORT, host: HOST });
    logger.info({ host: HOST, port: PORT }, `StreamForge API listening`);
    logger.info(`API docs: http://localhost:${PORT}/docs`);
  } catch (err) {
    logger.fatal({ err }, 'Failed to start server');
    process.exit(1);
  }
}

// ---- Graceful shutdown ----
const shutdown = async (signal) => {
  logger.info({ signal }, 'Shutting down...');
  await fastify.close();
  process.exit(0);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

start();
