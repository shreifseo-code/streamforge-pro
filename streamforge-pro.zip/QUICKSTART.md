# StreamForge Pro — Quick Start (5 دقائق)

## المتطلبات الأساسية
- Docker + Docker Compose
- 2GB RAM + 20GB disk
- Ubuntu/Debian (موصى به)

---

## الخطوات

### 1. احصل على الملفات
```bash
unzip streamforge-pro.zip
cd streamforge-pro
```

### 2. أعدّ البيئة
```bash
cp .env.example .env

# عدّل الأسرار (استخدم openssl rand -base64 32)
nano .env
```

**أهم التعديلات**:
```bash
JWT_SECRET=YOUR_64_CHAR_RANDOM_STRING_HERE_12345
DB_PASSWORD=your-strong-password-123
REDIS_PASSWORD=your-redis-password-456
ADMIN_PASSWORD=AdminPass123!@#
```

### 3. شغّل
```bash
docker-compose up -d
```

### 4. تحقق
```bash
docker-compose ps
# جميع الحاويات يجب أن تظهر "Up"

# هل كل شيء يعمل؟
curl http://localhost:3000/health
# {"status":"ok","version":"1.0.0","db":true}
```

### 5. دخول
```
Dashboard:  http://localhost
API Docs:   http://localhost:3000/docs
Email:      admin@streamforge.local
Password:   (من Admin_PASSWORD في .env)
```

---

## اختبار البث

### OBS / Streamlabs
```
Server:     rtmp://YOUR_IP:1935/live
Stream Key: (من Dashboard → Streams → copy)
```

### المشاهدة
```
https://localhost:8080/live/STREAM_KEY/index.m3u8
```

---

## الملفات المهمة

| الملف | اقرأ أنت |
|---|---|
| `PROJECT_STATUS.md` | حالة المشروع |
| `DEPLOYMENT.md` | نشر على السيرفر |
| `API.md` | جميع الـ endpoints |
| `TROUBLESHOOTING.md` | حل المشاكل |

---

## المشاكل الشائعة

### الحاوية لا تبدأ
```bash
docker-compose logs postgres
docker-compose down -v
docker-compose up -d
```

### لا أستطيع إرسال RTMP
```bash
# افتح الميناء
sudo ufw allow 1935/tcp

# أعد التشغيل
docker-compose restart nginx-rtmp
```

### "401 Unauthorized"
```bash
# سجّل الدخول مجدداً من Dashboard
# أو استخدم المسار: /auth/login
```

---

**انتهى! الآن لديك نظام بث عامل بالكامل** 🚀

للتفاصيل → اقرأ الملفات الأخرى.
