# StreamForge Pro — Troubleshooting Guide

## 🔴 المشاكل الشائعة والحلول

---

## الحاويات

### ❌ الحاوية لا تبدأ أو تتوقف فوراً

```bash
# 1. تحقق من السجلات
docker-compose logs postgres
docker-compose logs api
docker-compose logs nginx-rtmp

# 2. تحقق من الموارد
docker stats

# 3. إذا كان التالف ميموري:
docker-compose down -v  # احذف الحجوم
docker-compose up -d
```

---

### ❌ "Connection refused" من API إلى PostgreSQL

**الأسباب**: 
- PostgreSQL لم يبدأ بعد
- كلمة مرور خاطئة في `.env`
- الاتصال عام غير صحيح

**الحل**:
```bash
# تحقق من حالة PostgreSQL
docker-compose ps postgres
docker-compose logs postgres

# أعد تشغيلها
docker-compose restart postgres

# اختبر الاتصال
docker-compose exec api node -e \
  "const pg = require('pg'); const pool = new pg.Pool({...}); pool.query('SELECT NOW()').then(r => console.log(r.rows[0]))"
```

---

### ❌ Redis connection timeout

**السبب**: كلمة مرور Redis خاطئة

**الحل**:
```bash
# تحقق من `.env`
grep REDIS_PASSWORD .env

# أعد تشغيل Redis
docker-compose restart redis

# اختبر الاتصال
docker-compose exec redis redis-cli -a YOUR_PASSWORD ping
# يجب أن يطبع: PONG
```

---

## البث (RTMP)

### ❌ "Connection refused" عند الإرسال RTMP

**الأسباب**:
- Nginx-RTMP لم يبدأ
- الميناء 1935 مسدود بواسطة جدار الحماية
- الـ IP خاطئ

**الحل**:
```bash
# 1. تحقق من Nginx
docker-compose logs nginx-rtmp

# 2. افتح الميناء (إذا كان UFW مفعّل)
sudo ufw allow 1935/tcp

# 3. اختبر الاتصال
nc -zv YOUR_SERVER_IP 1935
# يجب أن يطبع: succeeded

# 4. أعد تشغيل Nginx
docker-compose restart nginx-rtmp
```

---

### ❌ "onPublish: unknown stream key"

**السبب**: API لم تتعرف على stream key

**الحل**:
```bash
# 1. تحقق من أن الـ stream موجود في DB
docker-compose exec postgres psql -U streamforge -d streamforge -c \
  "SELECT id, stream_key, status FROM streams WHERE stream_key='YOUR_KEY';"

# 2. تحقق من أن API تعمل
curl -X POST http://localhost:3000/api/v1/streams/rtmp/publish \
  -H "X-RTMP-Secret: YOUR_SECRET" \
  -d '{"name":"test_key","addr":"127.0.0.1"}'

# 3. تحقق من رأس RTMP_HOOK_SECRET في .env
grep RTMP_HOOK_SECRET .env
```

---

### ❌ HLS playback بطيء جداً

**الأسباب**:
- bandwidth عالي جداً
- transcoding مفقود
- شبكة سيئة

**الحل**:
```bash
# 1. تحقق من حجم الملف
du -sh /tmp/hls/YOUR_KEY/

# 2. قلل الـ bitrate في OBS
# الإعدادات → الإخراج → 3000-4000 kbps

# 3. تحقق من جودة الشبكة
iperf3 -c YOUR_SERVER_IP

# 4. فعّل CDN (Cloudflare)
```

---

## API

### ❌ "401 Unauthorized" على كل الطلبات

**الأسباب**:
- التوكن منتهي الصلاحية
- رأس Authorization مفقود
- التوكن نفسه غير صحيح

**الحل**:
```bash
# 1. تسجيل الدخول للحصول على توكن جديد
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@streamforge.local","password":"..."}'

# 2. استخدم التوكن الجديد
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:3000/api/v1/users
```

---

### ❌ "403 Forbidden" على الـ admin endpoint

**السبب**: المستخدم ليس admin

**الحل**:
```bash
# تحقق من الـ role
curl -H "Authorization: Bearer YOUR_TOKEN" \
  http://localhost:3000/api/v1/auth/me
# يجب أن تظهر: "role": "admin" أو "superadmin"

# إذا كنت مستخدماً عادياً:
# استخدم حساب admin للعملية
```

---

### ❌ "404 Not Found" على endpoint موجود

**الأسباب**:
- typo في الـ URL
- API لم تبدأ
- الـ endpoint مختلف في النسخة الحالية

**الحل**:
```bash
# تحقق من الحالة
curl http://localhost:3000/health

# اعرض جميع الـ endpoints
curl http://localhost:3000/docs

# أعد تشغيل API
docker-compose restart api
```

---

### ❌ "429 Too Many Requests"

**السبب**: تجاوزت حد المعدل

**الحل**:
```bash
# انتظر 60 ثانية
sleep 60

# أو زيادة الحد في .env
RATE_LIMIT_MAX=500

# أعد تشغيل API
docker-compose restart api
```

---

## قاعدة البيانات

### ❌ "FATAL: remaining connection slots reserved"

**السبب**: الكثير من الاتصالات المتزامنة

**الحل**:
```bash
# 1. اعرض الاتصالات النشطة
docker-compose exec postgres psql -U streamforge -d streamforge -c \
  "SELECT datname, count(*) FROM pg_stat_activity GROUP BY datname;"

# 2. قتل الاتصالات الخاملة
docker-compose exec postgres psql -U streamforge -d streamforge -c \
  "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'idle' AND query_start < NOW() - INTERVAL '30 minutes';"

# 3. زيادة الاتصالات المسموحة في docker-compose.yml
# environment:
#   POSTGRES_INIT_ARGS: "-c max_connections=200"
```

---

### ❌ "Disk full" — لا مساحة متبقية

**السبب**: سجلات أو بيانات ضخمة

**الحل**:
```bash
# تحقق من الاستخدام
docker system df

# احذف الحاويات والصور غير المستخدمة
docker system prune -a --volumes

# تنظيف السجلات
docker-compose exec postgres vacuumdb -U streamforge -d streamforge

# احذف الـ HLS القديمة
find /tmp/hls -mtime +7 -delete
find /tmp/dash -mtime +7 -delete
```

---

## الأداء

### ❌ CPU عالي جداً (> 80%)

**الأسباب**:
- البث كثير
- transcoding مفعّل
- query بطيء

**الحل**:
```bash
# 1. تحقق من العمليات الثقيلة
docker stats

# 2. تحقق من الـ queries البطيئة
docker-compose exec postgres psql -U streamforge -d streamforge -c \
  "SELECT query, mean_exec_time FROM pg_stat_statements ORDER BY mean_exec_time DESC LIMIT 10;"

# 3. أضف فهارس
docker-compose exec postgres psql -U streamforge -d streamforge -c \
  "CREATE INDEX IF NOT EXISTS idx_streams_user_status ON streams(user_id, status);"

# 4. زيادة موارد الحاوية
# في docker-compose.yml:
# api:
#   deploy:
#     resources:
#       limits:
#         cpus: '2'
#         memory: 2G
```

---

### ❌ الذاكرة ممتلئة (RAM > 90%)

**السبب**: تسرب ذاكرة في API أو حاويات ثقيلة

**الحل**:
```bash
# 1. تحقق من استخدام الذاكرة
docker stats --no-stream

# 2. أعد تشغيل الحاوية الثقيلة
docker-compose restart api

# 3. قلل حجم البيانات المخزنة مؤقتاً في Redis
docker-compose exec redis redis-cli DBSIZE
docker-compose exec redis redis-cli FLUSHDB

# 4. زيادة الـ RAM للحاوية
# في docker-compose.yml:
# api:
#   deploy:
#     resources:
#       limits:
#         memory: 2G
```

---

## SSL/TLS

### ❌ "certificate verify failed"

**السبب**: شهادة SSL قديمة أو مفقودة

**الحل**:
```bash
# 1. تحقق من الشهادة
openssl s_client -connect api.streamforge.yourdomain.com:443

# 2. جدد الشهادة
sudo certbot renew --dry-run
sudo certbot renew

# 3. أعد تحميل Nginx
sudo systemctl reload nginx
```

---

### ❌ "SSL handshake failed"

**السبب**: إصدار TLS قديم جداً

**الحل**:
```bash
# 1. تحقق من إصدار التطبيق
curl -I https://api.streamforge.yourdomain.com

# 2. في nginx.conf، تأكد من:
ssl_protocols TLSv1.2 TLSv1.3;

# 3. أعد تشغيل Nginx
sudo systemctl restart nginx
```

---

## نسخ احتياطية

### ❌ النسخة الاحتياطية لا تعمل

**السبب**: أذونات أو مساحة

**الحل**:
```bash
# 1. تحقق من نص البرنامج
bash /opt/streamforge-pro/backup.sh

# 2. تحقق من الأذونات
ls -la /opt/streamforge-pro/backups/

# 3. تحقق من مساحة القرص
df -h

# 4. تشغيل النسخة يدويًا
docker-compose exec postgres pg_dump -U streamforge streamforge | gzip > /tmp/backup.sql.gz
```

---

## دعم سريع

```bash
# أول شيء: اجمع المعلومات
docker-compose ps
docker-compose logs --tail 100
docker system df
docker stats --no-stream

# ثاني شيء: أعد تشغيل كل شيء
docker-compose down
docker-compose up -d

# ثالث شيء: اختبر الصحة
curl http://localhost:3000/health
curl http://localhost:8080/health
```

---

## اتصل بنا

- **المشاكل**: GitHub Issues
- **الأسئلة**: Discussions
- **الطوارئ**: support@streamforge.io

---

**آخر تحديث**: مايو 2026
